--
-- PostgreSQL database dump
--

\restrict oOtTiLJepjFDz7bp80b3kJXtFZZglysrkaijWvxW8UBKxMuDA7fXclJedtXM7BP

-- Dumped from database version 17.4 (Postgres.app)
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: clean_expired_verification_codes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.clean_expired_verification_codes() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM verification_codes WHERE expires_at < CURRENT_TIMESTAMP;
END;
$$;


ALTER FUNCTION public.clean_expired_verification_codes() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_user (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(255) NOT NULL,
    last_login_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.admin_user OWNER TO postgres;

--
-- Name: admin_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admin_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_user_id_seq OWNER TO postgres;

--
-- Name: admin_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admin_user_id_seq OWNED BY public.admin_user.id;


--
-- Name: app_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_versions (
    id integer NOT NULL,
    version character varying(50) NOT NULL,
    platform character varying(20) NOT NULL,
    distribution_type character varying(20) DEFAULT 'oss'::character varying,
    package_url text,
    oss_object_key character varying(500),
    release_notes text,
    status character varying(20) DEFAULT 'draft'::character varying,
    is_force_update boolean DEFAULT false,
    min_supported_version character varying(50),
    file_size bigint DEFAULT 0,
    file_hash character varying(128),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    published_at timestamp with time zone,
    created_by character varying(100)
);


ALTER TABLE public.app_versions OWNER TO postgres;

--
-- Name: TABLE app_versions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.app_versions IS 'Application version upgrade information table';


--
-- Name: COLUMN app_versions.version; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.app_versions.version IS 'Version number';


--
-- Name: COLUMN app_versions.platform; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.app_versions.platform IS 'Platform: windows, android, ios';


--
-- Name: COLUMN app_versions.distribution_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.app_versions.distribution_type IS 'Distribution type: oss(OSS file), url(external link like TestFlight)';


--
-- Name: COLUMN app_versions.package_url; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.app_versions.package_url IS 'Upgrade package download address/distribution address';


--
-- Name: COLUMN app_versions.oss_object_key; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.app_versions.oss_object_key IS 'OSS object storage key (only for oss type)';


--
-- Name: COLUMN app_versions.release_notes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.app_versions.release_notes IS 'Upgrade description information';


--
-- Name: COLUMN app_versions.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.app_versions.status IS 'Status: draft, published, deprecated';


--
-- Name: COLUMN app_versions.is_force_update; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.app_versions.is_force_update IS 'Whether to force update';


--
-- Name: COLUMN app_versions.min_supported_version; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.app_versions.min_supported_version IS 'Minimum supported version';


--
-- Name: COLUMN app_versions.file_size; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.app_versions.file_size IS 'File size (bytes, only for oss type)';


--
-- Name: COLUMN app_versions.file_hash; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.app_versions.file_hash IS 'File hash value (only for oss type)';


--
-- Name: app_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.app_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.app_versions_id_seq OWNER TO postgres;

--
-- Name: app_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.app_versions_id_seq OWNED BY public.app_versions.id;


--
-- Name: device_registrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.device_registrations (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    request_ip character varying(50) NOT NULL,
    platform character varying(20) NOT NULL,
    system_info jsonb NOT NULL,
    installed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.device_registrations OWNER TO postgres;

--
-- Name: TABLE device_registrations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.device_registrations IS 'Device registration table: records device information on first app startup';


--
-- Name: COLUMN device_registrations.uuid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.device_registrations.uuid IS 'Database encryption key UUID (original UUID, not MD5 encrypted)';


--
-- Name: COLUMN device_registrations.request_ip; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.device_registrations.request_ip IS 'Client request IP address';


--
-- Name: COLUMN device_registrations.platform; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.device_registrations.platform IS 'Operating system platform: android, ios, windows, macos, linux';


--
-- Name: COLUMN device_registrations.system_info; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.device_registrations.system_info IS 'System detailed information in JSON format, includes device model, OS version, etc';


--
-- Name: COLUMN device_registrations.installed_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.device_registrations.installed_at IS 'Application first installation/startup time';


--
-- Name: device_registrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.device_registrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.device_registrations_id_seq OWNER TO postgres;

--
-- Name: device_registrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.device_registrations_id_seq OWNED BY public.device_registrations.id;


--
-- Name: favorite_contacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.favorite_contacts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    contact_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.favorite_contacts OWNER TO postgres;

--
-- Name: TABLE favorite_contacts; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.favorite_contacts IS 'Favorite Contacts Table';


--
-- Name: COLUMN favorite_contacts.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorite_contacts.user_id IS 'User ID';


--
-- Name: COLUMN favorite_contacts.contact_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorite_contacts.contact_id IS 'Favorite contact ID';


--
-- Name: COLUMN favorite_contacts.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorite_contacts.created_at IS 'Created at';


--
-- Name: favorite_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.favorite_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.favorite_contacts_id_seq OWNER TO postgres;

--
-- Name: favorite_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.favorite_contacts_id_seq OWNED BY public.favorite_contacts.id;


--
-- Name: favorite_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.favorite_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.favorite_groups OWNER TO postgres;

--
-- Name: TABLE favorite_groups; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.favorite_groups IS 'Favorite Groups Table';


--
-- Name: COLUMN favorite_groups.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorite_groups.user_id IS 'User ID';


--
-- Name: COLUMN favorite_groups.group_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorite_groups.group_id IS 'Favorite group ID';


--
-- Name: COLUMN favorite_groups.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorite_groups.created_at IS 'Created at';


--
-- Name: favorite_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.favorite_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.favorite_groups_id_seq OWNER TO postgres;

--
-- Name: favorite_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.favorite_groups_id_seq OWNED BY public.favorite_groups.id;


--
-- Name: favorites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.favorites (
    id integer NOT NULL,
    user_id integer NOT NULL,
    message_id integer,
    content text NOT NULL,
    message_type character varying(50) DEFAULT 'text'::character varying,
    file_name character varying(255),
    sender_id integer NOT NULL,
    sender_name character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    server_id integer,
    sync_status character varying(20) DEFAULT 'synced'::character varying
);


ALTER TABLE public.favorites OWNER TO postgres;

--
-- Name: TABLE favorites; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.favorites IS 'User Favorite Messages Table';


--
-- Name: COLUMN favorites.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorites.user_id IS 'User ID who favorited this message';


--
-- Name: COLUMN favorites.message_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorites.message_id IS 'Favorited message ID (nullable if original message is deleted)';


--
-- Name: COLUMN favorites.content; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorites.content IS 'Message content';


--
-- Name: COLUMN favorites.message_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorites.message_type IS 'Message type: text, image, file, quoted';


--
-- Name: COLUMN favorites.file_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorites.file_name IS 'File name (for file type)';


--
-- Name: COLUMN favorites.sender_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorites.sender_id IS 'Original message sender ID';


--
-- Name: COLUMN favorites.sender_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorites.sender_name IS 'Original message sender name';


--
-- Name: COLUMN favorites.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.favorites.created_at IS 'Favorited at';


--
-- Name: favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.favorites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.favorites_id_seq OWNER TO postgres;

--
-- Name: favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.favorites_id_seq OWNED BY public.favorites.id;


--
-- Name: file_assistant_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_assistant_messages (
    id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    message_type character varying(50) DEFAULT 'text'::character varying,
    file_name character varying(255),
    quoted_message_id integer,
    quoted_message_content text,
    status character varying(20) DEFAULT 'normal'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    server_id integer
);


ALTER TABLE public.file_assistant_messages OWNER TO postgres;

--
-- Name: TABLE file_assistant_messages; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.file_assistant_messages IS 'File Assistant Messages Table';


--
-- Name: COLUMN file_assistant_messages.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.file_assistant_messages.user_id IS 'User ID';


--
-- Name: COLUMN file_assistant_messages.content; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.file_assistant_messages.content IS 'Message content';


--
-- Name: COLUMN file_assistant_messages.message_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.file_assistant_messages.message_type IS 'Message type: text, image, file, quoted';


--
-- Name: COLUMN file_assistant_messages.file_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.file_assistant_messages.file_name IS 'File name (for file type)';


--
-- Name: COLUMN file_assistant_messages.quoted_message_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.file_assistant_messages.quoted_message_id IS 'Quoted message ID';


--
-- Name: COLUMN file_assistant_messages.quoted_message_content; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.file_assistant_messages.quoted_message_content IS 'Quoted message content';


--
-- Name: COLUMN file_assistant_messages.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.file_assistant_messages.status IS 'Message status: normal, recalled';


--
-- Name: COLUMN file_assistant_messages.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.file_assistant_messages.created_at IS 'Created at';


--
-- Name: file_assistant_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.file_assistant_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.file_assistant_messages_id_seq OWNER TO postgres;

--
-- Name: file_assistant_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.file_assistant_messages_id_seq OWNED BY public.file_assistant_messages.id;


--
-- Name: group_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.group_members (
    id integer NOT NULL,
    group_id integer NOT NULL,
    user_id integer NOT NULL,
    nickname character varying(100),
    remark character varying(255),
    role character varying(20) DEFAULT 'member'::character varying,
    joined_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_muted boolean DEFAULT false,
    approval_status character varying(20) DEFAULT 'approved'::character varying,
    do_not_disturb boolean DEFAULT false,
    CONSTRAINT check_approval_status CHECK (((approval_status)::text = ANY (ARRAY[('pending'::character varying)::text, ('approved'::character varying)::text, ('rejected'::character varying)::text])))
);


ALTER TABLE public.group_members OWNER TO postgres;

--
-- Name: COLUMN group_members.is_muted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.group_members.is_muted IS 'Whether the member is muted';


--
-- Name: COLUMN group_members.approval_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.group_members.approval_status IS 'Approval status: pending, approved, rejected';


--
-- Name: COLUMN group_members.do_not_disturb; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.group_members.do_not_disturb IS 'Do not disturb: true displays only a red dot, false displays unread message count';


--
-- Name: group_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.group_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.group_members_id_seq OWNER TO postgres;

--
-- Name: group_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.group_members_id_seq OWNED BY public.group_members.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    announcement text,
    avatar character varying(255),
    owner_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    deleted_at timestamp without time zone,
    all_muted boolean DEFAULT false NOT NULL,
    invite_confirmation boolean DEFAULT false,
    admin_only_edit_name boolean DEFAULT false NOT NULL,
    member_view_permission boolean DEFAULT true,
    agora_group_id character varying(64)
);


ALTER TABLE public.groups OWNER TO postgres;

--
-- Name: COLUMN groups.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.groups.deleted_at IS 'Soft delete timestamp (NULL means not deleted)';


--
-- Name: COLUMN groups.all_muted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.groups.all_muted IS 'Whether all members are muted';


--
-- Name: COLUMN groups.invite_confirmation; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.groups.invite_confirmation IS 'Enable group invite confirmation (member invitations require approval)';


--
-- Name: COLUMN groups.admin_only_edit_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.groups.admin_only_edit_name IS 'Whether only the group owner/admins can modify the group name';


--
-- Name: COLUMN groups.member_view_permission; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.groups.member_view_permission IS 'Member view permission: true = regular members can view other members'' information, false = only the owner and administrators can view member information.';


--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.groups_id_seq OWNER TO postgres;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: invite_code_usages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invite_code_usages (
    id integer NOT NULL,
    invite_code_id integer NOT NULL,
    user_id integer NOT NULL,
    used_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.invite_code_usages OWNER TO postgres;

--
-- Name: invite_code_usages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invite_code_usages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invite_code_usages_id_seq OWNER TO postgres;

--
-- Name: invite_code_usages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invite_code_usages_id_seq OWNED BY public.invite_code_usages.id;


--
-- Name: invite_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invite_codes (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'unused'::character varying,
    used_by_user_id integer,
    used_by_username character varying(100),
    used_by_fullname character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    used_at timestamp without time zone,
    total_count integer DEFAULT 1,
    used_count integer DEFAULT 0,
    remark character varying(500)
);


ALTER TABLE public.invite_codes OWNER TO postgres;

--
-- Name: invite_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invite_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invite_codes_id_seq OWNER TO postgres;

--
-- Name: invite_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invite_codes_id_seq OWNED BY public.invite_codes.id;


--
-- Name: scheduled_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scheduled_messages (
    id integer NOT NULL,
    sender_id integer NOT NULL,
    receiver_id integer NOT NULL,
    message_type character varying(20) DEFAULT 'private'::character varying NOT NULL,
    title character varying(100) NOT NULL,
    send_time character varying(5) NOT NULL,
    send_type character varying(20) DEFAULT 'once'::character varying NOT NULL,
    content text NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    send_date character varying(10)
);


ALTER TABLE public.scheduled_messages OWNER TO postgres;

--
-- Name: TABLE scheduled_messages; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.scheduled_messages IS '定时消息表';


--
-- Name: COLUMN scheduled_messages.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.scheduled_messages.id IS '主键ID';


--
-- Name: COLUMN scheduled_messages.sender_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.scheduled_messages.sender_id IS '发送人ID';


--
-- Name: COLUMN scheduled_messages.receiver_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.scheduled_messages.receiver_id IS '接收人ID（私聊为用户ID，群聊为群组ID）';


--
-- Name: COLUMN scheduled_messages.message_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.scheduled_messages.message_type IS '类型：private-私聊，group-群聊';


--
-- Name: COLUMN scheduled_messages.title; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.scheduled_messages.title IS '任务标题';


--
-- Name: COLUMN scheduled_messages.send_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.scheduled_messages.send_time IS '发送时间（HH:MM格式）';


--
-- Name: COLUMN scheduled_messages.send_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.scheduled_messages.send_type IS '发送类型：once-单次，daily-每日';


--
-- Name: COLUMN scheduled_messages.content; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.scheduled_messages.content IS '消息内容（最多1000字）';


--
-- Name: COLUMN scheduled_messages.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.scheduled_messages.status IS '任务状态：pending-待发送，sent-已发送，deleted-已删除';


--
-- Name: COLUMN scheduled_messages.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.scheduled_messages.created_at IS '创建时间';


--
-- Name: COLUMN scheduled_messages.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.scheduled_messages.updated_at IS '更新时间';


--
-- Name: COLUMN scheduled_messages.send_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.scheduled_messages.send_date IS 'Send date (YYYY-MM-DD format, for once type only)';


--
-- Name: scheduled_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.scheduled_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scheduled_messages_id_seq OWNER TO postgres;

--
-- Name: scheduled_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.scheduled_messages_id_seq OWNED BY public.scheduled_messages.id;


--
-- Name: server_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.server_settings (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    value text NOT NULL,
    description character varying(255) DEFAULT ''::character varying,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.server_settings OWNER TO postgres;

--
-- Name: TABLE server_settings; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.server_settings IS 'Server Settings Table';


--
-- Name: server_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.server_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.server_settings_id_seq OWNER TO postgres;

--
-- Name: server_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.server_settings_id_seq OWNED BY public.server_settings.id;


--
-- Name: synced_group_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.synced_group_messages (
    id bigint NOT NULL,
    agora_msg_id character varying(64) NOT NULL,
    group_id integer NOT NULL,
    sender_id integer NOT NULL,
    sender_name character varying(255) DEFAULT ''::character varying,
    sender_nickname character varying(255),
    sender_full_name character varying(255),
    content text DEFAULT ''::text,
    message_type character varying(32) DEFAULT 'text'::character varying,
    file_name character varying(512),
    voice_duration integer,
    call_type character varying(32),
    quoted_message_content text,
    status character varying(16) DEFAULT 'normal'::character varying,
    created_at timestamp without time zone NOT NULL,
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.synced_group_messages OWNER TO postgres;

--
-- Name: synced_group_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.synced_group_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.synced_group_messages_id_seq OWNER TO postgres;

--
-- Name: synced_group_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.synced_group_messages_id_seq OWNED BY public.synced_group_messages.id;


--
-- Name: synced_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.synced_messages (
    id bigint NOT NULL,
    agora_msg_id character varying(64) NOT NULL,
    sender_id integer NOT NULL,
    sender_name character varying(255) DEFAULT ''::character varying,
    receiver_id integer NOT NULL,
    receiver_name character varying(255) DEFAULT ''::character varying,
    content text DEFAULT ''::text,
    message_type character varying(32) DEFAULT 'text'::character varying,
    file_name character varying(512),
    voice_duration integer,
    call_type character varying(32),
    quoted_message_content text,
    status character varying(16) DEFAULT 'normal'::character varying,
    is_read boolean DEFAULT false,
    created_at timestamp without time zone NOT NULL,
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.synced_messages OWNER TO postgres;

--
-- Name: synced_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.synced_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.synced_messages_id_seq OWNER TO postgres;

--
-- Name: synced_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.synced_messages_id_seq OWNED BY public.synced_messages.id;


--
-- Name: user_relations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_relations (
    id integer NOT NULL,
    user_id integer NOT NULL,
    friend_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    approval_status character varying(20) DEFAULT 'approved'::character varying NOT NULL,
    is_blocked boolean DEFAULT false NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    blocked_by_user_id integer,
    deleted_by_user_id integer,
    CONSTRAINT check_approval_status CHECK (((approval_status)::text = ANY (ARRAY[('pending'::character varying)::text, ('approved'::character varying)::text, ('rejected'::character varying)::text])))
);


ALTER TABLE public.user_relations OWNER TO postgres;

--
-- Name: TABLE user_relations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.user_relations IS 'User Relations Table';


--
-- Name: COLUMN user_relations.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_relations.user_id IS 'User ID';


--
-- Name: COLUMN user_relations.friend_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_relations.friend_id IS 'Friend user ID';


--
-- Name: COLUMN user_relations.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_relations.created_at IS 'Created at';


--
-- Name: COLUMN user_relations.approval_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_relations.approval_status IS 'Approval status: pending, approved, rejected';


--
-- Name: COLUMN user_relations.is_blocked; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_relations.is_blocked IS 'Whether the user is blocked; true means blocked';


--
-- Name: COLUMN user_relations.is_deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_relations.is_deleted IS 'Whether the relation is deleted (soft delete); true means deleted';


--
-- Name: COLUMN user_relations.blocked_by_user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_relations.blocked_by_user_id IS 'User ID who performed the block operation';


--
-- Name: COLUMN user_relations.deleted_by_user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_relations.deleted_by_user_id IS 'User ID who performed the delete operation';


--
-- Name: user_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_relations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_relations_id_seq OWNER TO postgres;

--
-- Name: user_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_relations_id_seq OWNED BY public.user_relations.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(255) NOT NULL,
    phone character varying(20) DEFAULT NULL::character varying,
    email character varying(100) DEFAULT NULL::character varying,
    avatar character varying(255) DEFAULT ''::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    auth_code character varying(100) DEFAULT NULL::character varying,
    full_name character varying(100) DEFAULT NULL::character varying,
    gender character varying(10) DEFAULT NULL::character varying,
    work_signature character varying(500) DEFAULT NULL::character varying,
    status character varying(50) DEFAULT 'offline'::character varying,
    landline character varying(20) DEFAULT NULL::character varying,
    short_number character varying(10) DEFAULT NULL::character varying,
    department character varying(100) DEFAULT NULL::character varying,
    "position" character varying(100) DEFAULT NULL::character varying,
    region character varying(100) DEFAULT NULL::character varying,
    invite_code character varying(6) DEFAULT NULL::character varying,
    invited_by_code character varying(6) DEFAULT NULL::character varying,
    voip_token character varying(255),
    voip_token_updated_at timestamp without time zone,
    last_login_at timestamp without time zone,
    is_overseas smallint DEFAULT 1,
    active_token text,
    token_updated_at timestamp with time zone,
    remark character varying(500),
    CONSTRAINT check_gender CHECK (((gender)::text = ANY (ARRAY[(NULL::character varying)::text, ('male'::character varying)::text, ('female'::character varying)::text, ('other'::character varying)::text]))),
    CONSTRAINT check_status CHECK (((status)::text = ANY (ARRAY[('online'::character varying)::text, ('busy'::character varying)::text, ('away'::character varying)::text, ('offline'::character varying)::text])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.users IS 'Users Table';


--
-- Name: COLUMN users.auth_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.auth_code IS 'Authorization code';


--
-- Name: COLUMN users.full_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.full_name IS 'Full name';


--
-- Name: COLUMN users.gender; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.gender IS 'Gender: male, female, other';


--
-- Name: COLUMN users.work_signature; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.work_signature IS 'Work signature';


--
-- Name: COLUMN users.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.status IS 'Status: online, busy, away, offline';


--
-- Name: COLUMN users.landline; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.landline IS 'Landline';


--
-- Name: COLUMN users.short_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.short_number IS 'Short number';


--
-- Name: COLUMN users.department; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.department IS 'Department';


--
-- Name: COLUMN users."position"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users."position" IS 'Position';


--
-- Name: COLUMN users.region; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.region IS 'Region';


--
-- Name: COLUMN users.invite_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.invite_code IS 'User''s own invite code (6 characters, 0-9a-zA-Z)';


--
-- Name: COLUMN users.invited_by_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.invited_by_code IS 'Invite code used during registration';


--
-- Name: COLUMN users.voip_token; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.voip_token IS 'iOS VoIP Push Token，用于后台来电推送';


--
-- Name: COLUMN users.voip_token_updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.voip_token_updated_at IS 'VoIP Token 最后更新时间';


--
-- Name: COLUMN users.last_login_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.last_login_at IS 'User last login timestamp';


--
-- Name: COLUMN users.is_overseas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.is_overseas IS 'Whether overseas user: 0-domestic, 1-overseas, default 1';


--
-- Name: COLUMN users.active_token; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.active_token IS 'Current valid login token for single device login restriction';


--
-- Name: COLUMN users.token_updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.token_updated_at IS 'Token update timestamp';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: verification_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verification_codes (
    id integer NOT NULL,
    account character varying(100) NOT NULL,
    code character varying(10) NOT NULL,
    type character varying(20) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT verification_codes_type_check CHECK (((type)::text = ANY (ARRAY[('login'::character varying)::text, ('register'::character varying)::text, ('reset'::character varying)::text])))
);


ALTER TABLE public.verification_codes OWNER TO postgres;

--
-- Name: TABLE verification_codes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.verification_codes IS 'Verification Codes Table';


--
-- Name: verification_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.verification_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.verification_codes_id_seq OWNER TO postgres;

--
-- Name: verification_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.verification_codes_id_seq OWNED BY public.verification_codes.id;


--
-- Name: admin_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_user ALTER COLUMN id SET DEFAULT nextval('public.admin_user_id_seq'::regclass);


--
-- Name: app_versions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_versions ALTER COLUMN id SET DEFAULT nextval('public.app_versions_id_seq'::regclass);


--
-- Name: device_registrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_registrations ALTER COLUMN id SET DEFAULT nextval('public.device_registrations_id_seq'::regclass);


--
-- Name: favorite_contacts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_contacts ALTER COLUMN id SET DEFAULT nextval('public.favorite_contacts_id_seq'::regclass);


--
-- Name: favorite_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_groups ALTER COLUMN id SET DEFAULT nextval('public.favorite_groups_id_seq'::regclass);


--
-- Name: favorites id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorites ALTER COLUMN id SET DEFAULT nextval('public.favorites_id_seq'::regclass);


--
-- Name: file_assistant_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_assistant_messages ALTER COLUMN id SET DEFAULT nextval('public.file_assistant_messages_id_seq'::regclass);


--
-- Name: group_members id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_members ALTER COLUMN id SET DEFAULT nextval('public.group_members_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: invite_code_usages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_code_usages ALTER COLUMN id SET DEFAULT nextval('public.invite_code_usages_id_seq'::regclass);


--
-- Name: invite_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_codes ALTER COLUMN id SET DEFAULT nextval('public.invite_codes_id_seq'::regclass);


--
-- Name: scheduled_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_messages ALTER COLUMN id SET DEFAULT nextval('public.scheduled_messages_id_seq'::regclass);


--
-- Name: server_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.server_settings ALTER COLUMN id SET DEFAULT nextval('public.server_settings_id_seq'::regclass);


--
-- Name: synced_group_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.synced_group_messages ALTER COLUMN id SET DEFAULT nextval('public.synced_group_messages_id_seq'::regclass);


--
-- Name: synced_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.synced_messages ALTER COLUMN id SET DEFAULT nextval('public.synced_messages_id_seq'::regclass);


--
-- Name: user_relations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_relations ALTER COLUMN id SET DEFAULT nextval('public.user_relations_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: verification_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_codes ALTER COLUMN id SET DEFAULT nextval('public.verification_codes_id_seq'::regclass);


--
-- Data for Name: admin_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_user (id, username, password, last_login_at, created_at) FROM stdin;
1	sanpao888	$2a$10$/4HqIjuKXG3v/eFK56cutevzOMhPxpd1VEJjGjYDMx8ouK7ir7n1m	2026-07-02 12:55:05.840598	2026-07-02 12:33:47.301836
\.


--
-- Data for Name: app_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_versions (id, version, platform, distribution_type, package_url, oss_object_key, release_notes, status, is_force_update, min_supported_version, file_size, file_hash, created_at, updated_at, published_at, created_by) FROM stdin;
2	1.0.23-1765520167	windows	url	https://xn--wxtp0q.vip/releases/windows/1.0.23-1765520167.zip		优化安装包下载和弹窗关闭问题	published	f		65322192	61a610e2b18bab7f5daddfdec0edb064	2025-12-10 23:59:46.57674+08	2025-12-14 16:38:42+08	2025-12-14 16:38:42+08	
4	1.0.23-1765520167	android	url	https://xn--wxtp0q.vip/releases/android/1.0.23-1765520167.apk		优化安装包下载和弹窗关闭问题	published	f		304619933	8ea6f67f23d4ebe7421a24d66d060165	2025-12-11 00:09:54.601814+08	2025-12-14 16:39:17+08	2025-12-14 16:39:17+08	
3	1.0.5+7	ios	url	https://testflight.apple.com/join/m6U2cVQe	\N	优化APP	published	f	\N	0	\N	2025-12-11 00:06:46.823815+08	2026-01-08 15:41:13+08	2026-01-08 15:41:13+08	
\.


--
-- Data for Name: device_registrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.device_registrations (id, uuid, request_ip, platform, system_info, installed_at, created_at, updated_at) FROM stdin;
1	65456255-5196-4d8a-96ee-0653cbf22b03	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 16:32:52.691175	2025-11-24 16:32:52.399671	2025-11-24 16:32:52.399671
2	73c978aa-91c1-4a78-a5b4-2f5fe96bdffb	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 16:59:42.547024	2025-11-24 16:59:42.160502	2025-11-24 16:59:42.160502
3	36f60dbf-5cb8-4f7a-811e-4df7a88fab98	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 17:03:19.046834	2025-11-24 17:03:18.664769	2025-11-24 17:03:18.664769
5	e1f51d0d-049b-4ac5-bb7e-d9b8fa6e597d	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 17:23:18.035138	2025-11-24 17:23:17.616277	2025-11-24 17:23:17.616277
6	6c330562-016b-4e2f-9ec8-4d37a07535a9	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 17:25:01.609749	2025-11-24 17:25:01.193762	2025-11-24 17:25:01.193762
7	08063d2e-5811-4d18-ad09-fe10d715cb6b	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 18:31:51.740815	2025-11-24 18:31:51.280192	2025-11-24 18:31:51.280192
8	e4b06750-ba49-41bc-b1cc-58a62a606aca	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 18:49:29.879892	2025-11-24 18:49:29.370826	2025-11-24 18:49:29.370826
9	3106432c-f53e-4404-9552-b5d8bba52c45	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 18:51:17.015426	2025-11-24 18:51:16.544603	2025-11-24 18:51:16.544603
10	56755645-eaf6-4c0f-9136-158f9cd83aa9	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 18:52:03.292145	2025-11-24 18:52:02.794389	2025-11-24 18:52:02.794389
11	82015ad5-9fb8-4903-8bc2-c37a96c3c31a	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 18:54:37.352337	2025-11-24 18:54:36.900083	2025-11-24 18:54:36.900083
12	fce81ded-188c-46ce-854e-6ebc582132ec	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 18:55:47.033147	2025-11-24 18:55:46.534483	2025-11-24 18:55:46.534483
13	ee37dbdd-c016-475f-9767-2a6aa09414ea	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 19:22:00.760805	2025-11-24 19:22:00.232015	2025-11-24 19:22:00.232015
14	e794de5d-438f-46e8-9aa8-06dcc3aacf75	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 19:36:29.31927	2025-11-24 19:36:28.853927	2025-11-24 19:36:28.853927
15	2389c0e7-eef1-4835-8ff3-b07fef2b424f	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 20:24:24.407072	2025-11-24 20:24:23.867995	2025-11-24 20:24:23.867995
16	e70cc0eb-5d3d-4b1e-8a4a-d36eaa377ff7	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 21:05:42.752888	2025-11-24 21:05:42.136421	2025-11-24 21:05:42.136421
17	87be40bb-b6b7-4316-902b-9d2bc986274a	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 21:09:35.86997	2025-11-24 21:09:35.240155	2025-11-24 21:09:35.240155
18	28b8a56e-4d1c-49e4-80ab-038c88e51465	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 21:25:37.164615	2025-11-24 21:25:37.906537	2025-11-24 21:25:37.906537
19	fade0452-0db9-4316-98ff-0c0c070fa0a7	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 21:43:45.453674	2025-11-24 21:43:44.941572	2025-11-24 21:43:44.941572
20	916c0ce5-3397-4266-bff2-401c3fc3935e	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 21:49:50.617456	2025-11-24 21:49:49.962452	2025-11-24 21:49:49.962452
21	4ef9553a-b4f0-4cce-9e40-88e74a087084	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 21:55:30.356098	2025-11-24 21:55:29.739815	2025-11-24 21:55:29.739815
22	809d2349-6474-4bc2-9bd5-a8f002d9a181	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 22:11:03.742009	2025-11-24 22:11:03.063577	2025-11-24 22:11:03.063577
23	584b8d8a-c699-459a-9ac1-efefd1394022	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 22:18:47.363102	2025-11-24 22:18:46.728666	2025-11-24 22:18:46.728666
24	b0b3eb0b-e7fa-49be-9296-dcc5e24de9a6	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 22:19:23.608649	2025-11-24 22:19:22.934494	2025-11-24 22:19:22.934494
25	c9445ad5-203c-4c46-b5c3-09cc919cec0c	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-24 22:34:33.1772	2025-11-24 22:34:32.479725	2025-11-24 22:34:32.479725
26	f27e50f7-83b8-483c-8ab1-b6c0b516cfd6	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 00:03:41.342239	2025-11-25 00:03:40.550861	2025-11-25 00:03:40.550861
27	d163df22-c6d1-400e-8143-462395277ed8	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 00:05:53.019333	2025-11-25 00:05:52.248281	2025-11-25 00:05:52.248281
28	22b596e4-b8c0-4957-bdbb-ce5f19178f67	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 00:16:17.107674	2025-11-25 00:16:16.353663	2025-11-25 00:16:16.353663
29	dff8391f-d956-43f3-999c-d7febcf0723e	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 08:18:10.978674	2025-11-25 08:18:11.49042	2025-11-25 08:18:11.49042
30	8d6a82ce-4f7b-47d6-aa16-41af524a9bcd	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 08:28:20.15522	2025-11-25 08:28:20.595404	2025-11-25 08:28:20.595404
31	48767bc9-275d-45c6-a9ad-c710b7a1ee63	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 08:34:24.036256	2025-11-25 08:34:24.494151	2025-11-25 08:34:24.494151
32	d5029c8f-892a-41e7-878a-ae03bffdd824	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 08:37:53.699159	2025-11-25 08:37:54.144359	2025-11-25 08:37:54.144359
33	cb15ceff-8484-4f69-b3db-3d4574d9d1ff	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 08:41:28.664037	2025-11-25 08:41:29.11547	2025-11-25 08:41:29.11547
34	7091dc72-2c27-4db4-88ad-88ad66bc84d2	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 08:47:21.316979	2025-11-25 08:47:23.160436	2025-11-25 08:47:23.160436
35	3eacb277-4129-4bf2-8767-9c2ca53afb9c	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 08:52:38.939582	2025-11-25 08:52:39.369406	2025-11-25 08:52:39.369406
36	c1135659-fcbc-414a-a2be-549c20ab7a58	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 08:56:09.652759	2025-11-25 08:56:10.085898	2025-11-25 08:56:10.085898
37	246ea2ea-bf1c-437e-abdc-e168e9569a13	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 08:56:25.013069	2025-11-25 08:56:25.450198	2025-11-25 08:56:25.450198
38	0558766f-0c26-4199-8282-b451ab49c91a	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 08:59:58.9532	2025-11-25 08:59:59.393356	2025-11-25 08:59:59.393356
39	d85b1192-9aa5-4a4c-9e8d-12839f376a02	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 09:02:09.025642	2025-11-25 09:02:09.455145	2025-11-25 09:02:09.455145
40	2f16f48b-bf89-4d63-8299-53d632537086	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 09:04:09.891849	2025-11-25 09:04:10.323325	2025-11-25 09:04:10.323325
41	bd33dc2f-a36a-4e25-b107-893dad65f2b8	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 09:10:04.785869	2025-11-25 09:10:05.23198	2025-11-25 09:10:05.23198
42	69586b51-c69e-4726-9256-6c5f7a33c8ab	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 09:14:08.319645	2025-11-25 09:14:08.730014	2025-11-25 09:14:08.730014
43	b56f40a7-e92e-4258-bbfd-3173222a9734	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 09:21:04.546752	2025-11-25 09:21:04.999374	2025-11-25 09:21:04.999374
44	762c6262-2e6c-41f2-bcad-9d0fd1fd992e	192.168.1.17	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "STF-AL10 9.0.1.179(C00E63R1P9)", "number_of_processors": 8}	2025-11-25 11:11:57.929186	2025-11-25 11:11:58.225914	2025-11-25 11:11:58.225914
45	fc544ae2-4b60-40a6-82d4-4ca1a84d1b29	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 11:19:30.049053	2025-11-25 11:19:29.020267	2025-11-25 11:19:29.020267
46	bd5019ba-a67c-4fbe-9537-c8d1174dce45	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 11:32:23.338895	2025-11-25 11:32:22.1247	2025-11-25 11:32:22.1247
47	33cc8ede-faf3-49d2-bd0f-aece1b7f18d9	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 11:35:58.716565	2025-11-25 11:35:58.376009	2025-11-25 11:35:58.376009
48	f2032178-76ce-47ff-a875-f9d3196c809c	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 11:53:03.75144	2025-11-25 11:53:04.111254	2025-11-25 11:53:04.111254
49	915c5527-cbef-40e7-a768-f9597a1d5093	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 11:54:37.821247	2025-11-25 11:54:37.867014	2025-11-25 11:54:37.867014
50	25236a4f-8012-419c-a570-89c479291a84	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 12:04:01.442658	2025-11-25 12:04:01.469949	2025-11-25 12:04:01.469949
51	a15ba249-f8d0-4bf7-9f7b-5cc1b805fb72	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 12:07:09.202745	2025-11-25 12:07:09.265357	2025-11-25 12:07:09.265357
52	1d02925d-f835-4f45-af50-7c995b6ace83	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 12:22:04.767515	2025-11-25 12:22:04.998069	2025-11-25 12:22:04.998069
53	77f31dae-e86d-4400-8bc3-3039363d511b	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 12:24:40.700709	2025-11-25 12:24:40.759095	2025-11-25 12:24:40.759095
54	e0330999-3e46-429b-bfd1-f3a136bb8e0e	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 12:29:12.995706	2025-11-25 12:29:13.014599	2025-11-25 12:29:13.014599
55	a752c3d7-80de-41ef-8863-234c552babb9	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 13:22:20.501071	2025-11-25 13:22:20.726887	2025-11-25 13:22:20.726887
56	7e3842d6-82e5-4336-bd4d-b5772e576edd	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 13:32:35.966598	2025-11-25 13:32:35.919187	2025-11-25 13:32:35.919187
58	b9e9764b-17dc-45b8-8bfd-2437f2c831d7	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 13:38:48.268297	2025-11-25 13:38:48.266142	2025-11-25 13:38:48.266142
59	c1e3880e-f5e8-4acf-ae02-5bfd9279a757	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 13:40:52.462031	2025-11-25 13:40:52.745461	2025-11-25 13:40:52.745461
57	ff0894cf-9adb-44c9-8095-29aff7f3edac	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 13:36:17.950608	2025-11-25 13:36:17.928761	2025-11-25 13:36:17.928761
60	83c48b4b-ce17-42f4-b6d6-01af0d53c6fe	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 14:01:45.321208	2025-11-25 14:01:45.232188	2025-11-25 14:01:45.232188
61	9f53e28c-5ff7-4540-979b-730ff0932744	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 14:04:36.057292	2025-11-25 14:04:36.027166	2025-11-25 14:04:36.027166
62	079fbc65-27aa-4912-8768-d3c8b0b658dc	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 14:10:26.108408	2025-11-25 14:10:26.048856	2025-11-25 14:10:26.048856
63	9d9f1cac-cce2-4adf-9279-370ac4be4d50	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 14:21:34.473242	2025-11-25 14:21:34.393043	2025-11-25 14:21:34.393043
64	24a39f06-b0a5-4d1d-b040-2b560147d0fd	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 14:24:09.402386	2025-11-25 14:24:09.312326	2025-11-25 14:24:09.312326
65	026bc387-61dd-46b3-843d-785a0652f76f	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 14:27:10.979887	2025-11-25 14:27:10.889383	2025-11-25 14:27:10.889383
66	d8f2fadc-5277-4424-9328-c4f60e5f8bef	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 15:38:53.010322	2025-11-25 15:38:52.868778	2025-11-25 15:38:52.868778
67	c738543c-08ec-4f34-96e7-0d399ac467d7	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 15:49:14.387703	2025-11-25 15:49:14.386368	2025-11-25 15:49:14.386368
68	0ade46ac-26a3-48b1-8fa4-a0afc0949115	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 17:19:30.403515	2025-11-25 17:19:30.267807	2025-11-25 17:19:30.267807
69	d8785cd2-4a5c-44c2-bd04-df053cec856a	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 17:43:38.497821	2025-11-25 17:43:38.219704	2025-11-25 17:43:38.219704
70	d52a6cfc-13ce-42ad-a6da-90ab5ceda3ea	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 17:53:00.457868	2025-11-25 17:53:00.19576	2025-11-25 17:53:00.19576
71	043c5242-06f3-49ca-bc85-3b6b3a13223a	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 18:11:45.130728	2025-11-25 18:11:44.82889	2025-11-25 18:11:44.82889
72	5f91a934-60a7-4157-ac39-156fe3ff9e43	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 18:38:22.495311	2025-11-25 18:38:22.216062	2025-11-25 18:38:22.216062
73	806d8ba8-104a-46ce-a417-0a7aeb0719c4	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 19:41:06.463983	2025-11-25 19:41:06.063551	2025-11-25 19:41:06.063551
74	76fb355c-64d8-4daf-913a-7fdb0c87c70c	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 19:42:38.706995	2025-11-25 19:42:38.306272	2025-11-25 19:42:38.306272
75	58f1e12d-4e2e-42be-bcb9-75117b170148	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 19:48:22.518389	2025-11-25 19:48:22.112773	2025-11-25 19:48:22.112773
76	4fefdba2-2bd0-4451-8f7c-4b5134c4144a	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 19:48:28.33671	2025-11-25 19:48:27.933706	2025-11-25 19:48:27.933706
77	4c75e6df-3eb7-45b6-b186-119753374a30	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 19:54:09.96777	2025-11-25 19:54:09.554267	2025-11-25 19:54:09.554267
78	d8d4acb8-4f4a-4022-9f47-3d91e51bd6a5	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 19:56:03.081249	2025-11-25 19:56:02.85509	2025-11-25 19:56:02.85509
79	2620a77f-a102-446b-b988-5d83d4ab5108	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:04:24.236337	2025-11-25 20:04:23.814206	2025-11-25 20:04:23.814206
80	6a4a6019-a6f2-4c93-a2f2-086e8f59a298	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:04:38.377972	2025-11-25 20:04:37.976805	2025-11-25 20:04:37.976805
81	fcec6d95-1d38-4886-bd3d-18b14e5fc325	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:06:26.82803	2025-11-25 20:06:26.475581	2025-11-25 20:06:26.475581
82	3f4b7969-a306-4256-b5c9-1492dab57cd0	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:10:57.856977	2025-11-25 20:10:57.43292	2025-11-25 20:10:57.43292
83	734e9b02-12b4-4bcc-8493-90cb15f2d20a	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:19:03.598085	2025-11-25 20:19:03.181447	2025-11-25 20:19:03.181447
84	a936ebac-6c57-41b4-b322-b59233603f9c	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:22:57.277069	2025-11-25 20:22:56.838712	2025-11-25 20:22:56.838712
85	4221d994-5b44-4b43-9716-6cd6d626504a	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:23:49.165553	2025-11-25 20:23:48.750801	2025-11-25 20:23:48.750801
86	0f0ba7fd-afba-4d2b-83e1-90c214ef7bc4	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:26:30.035708	2025-11-25 20:26:29.597847	2025-11-25 20:26:29.597847
87	6b92c8d7-a62a-4f55-94fb-9e25bb478a9d	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:28:56.748026	2025-11-25 20:28:58.263482	2025-11-25 20:28:58.263482
88	77e42379-69f8-48a9-ab40-a9951317079e	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:30:32.065887	2025-11-25 20:30:31.62035	2025-11-25 20:30:31.62035
89	d6467e49-2a40-482c-9025-d891461096b6	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:36:40.713391	2025-11-25 20:36:40.276314	2025-11-25 20:36:40.276314
90	347ea98e-e287-4072-8193-893b563747ae	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:40:20.988008	2025-11-25 20:40:20.535356	2025-11-25 20:40:20.535356
91	2373eecb-2b13-4c23-893e-5dab32491d0c	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:44:37.067307	2025-11-25 20:44:36.612692	2025-11-25 20:44:36.612692
92	eba49194-37ff-4779-9559-3d13370272bb	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 20:54:35.376118	2025-11-25 20:54:34.921801	2025-11-25 20:54:34.921801
93	ec655448-7286-4377-ab2a-16b3df0a0b68	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 21:23:21.979589	2025-11-25 21:23:21.508674	2025-11-25 21:23:21.508674
94	0c18308a-4149-4625-8927-1e515d6ce1fb	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 21:24:17.87072	2025-11-25 21:24:17.41687	2025-11-25 21:24:17.41687
95	612a609b-cd03-45ea-8c01-464a3458613a	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 21:39:20.61494	2025-11-25 21:39:20.117964	2025-11-25 21:39:20.117964
96	bb64819a-f399-4b0d-9404-684c3c34758c	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 21:46:43.35785	2025-11-25 21:46:42.882371	2025-11-25 21:46:42.882371
97	5dea924b-7ccd-49a7-9fe2-220059144a06	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 21:52:35.185834	2025-11-25 21:52:34.691173	2025-11-25 21:52:34.691173
98	57724f32-1297-490b-a22d-66c2ab551f2c	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 21:59:42.8241	2025-11-25 21:59:42.302139	2025-11-25 21:59:42.302139
99	49855997-3145-4ed1-8bd2-64eb54808e5e	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 22:33:34.191296	2025-11-25 22:33:33.639834	2025-11-25 22:33:33.639834
100	7858fe7a-7a4a-456a-af78-8e8a265fbd94	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 22:33:41.688928	2025-11-25 22:33:41.153782	2025-11-25 22:33:41.153782
101	59d7abd0-ef1e-4fb7-9ebd-30b6d0c4a2a6	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 22:55:15.255051	2025-11-25 22:55:14.679492	2025-11-25 22:55:14.679492
102	a9b6f598-995f-424b-a766-49c6d984b9ab	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 23:04:32.378093	2025-11-25 23:04:31.821277	2025-11-25 23:04:31.821277
103	30afb8de-4119-483f-8e0c-b41a06448a3d	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 23:06:26.89113	2025-11-25 23:06:26.373377	2025-11-25 23:06:26.373377
104	2a574dcd-2cee-434f-9552-75e9f67570f8	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 23:09:29.015874	2025-11-25 23:09:28.432674	2025-11-25 23:09:28.432674
105	ab9a6512-fc0b-478e-a467-69d6c08c74b2	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-25 23:10:48.161651	2025-11-25 23:10:47.585239	2025-11-25 23:10:47.585239
106	7502e17e-2335-4e91-9ed3-43607a99c314	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 07:37:15.095649	2025-11-26 07:37:15.071057	2025-11-26 07:37:15.071057
107	bb912307-7a38-45cb-a3ef-307ea953e5de	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 07:45:30.948205	2025-11-26 07:45:30.868409	2025-11-26 07:45:30.868409
108	0c2c6024-f7dd-4d63-9722-0adc4f483956	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 07:49:32.876205	2025-11-26 07:49:32.774263	2025-11-26 07:49:32.774263
109	e6d54af7-b374-41fb-bf75-1250ad486277	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 07:54:29.392304	2025-11-26 07:54:29.319695	2025-11-26 07:54:29.319695
110	0d9a2290-0dbd-448d-b55e-cd7e170e3719	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 07:56:37.549591	2025-11-26 07:56:37.43188	2025-11-26 07:56:37.43188
111	04d14f0b-791d-431a-bab2-d98bbdb25d89	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 07:58:16.969043	2025-11-26 07:58:16.854123	2025-11-26 07:58:16.854123
112	8b5ef048-8c53-4137-aa25-c68f775a9583	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 08:01:11.370084	2025-11-26 08:01:11.269399	2025-11-26 08:01:11.269399
113	bd87d81c-9401-451d-a5f9-31dba29f4608	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 08:31:29.203971	2025-11-26 08:31:29.095157	2025-11-26 08:31:29.095157
114	87994e87-18f1-461f-8fbc-9ab5bd4c3356	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 08:33:37.747346	2025-11-26 08:33:37.598261	2025-11-26 08:33:37.598261
115	8ec2fec1-02b8-4ec4-a001-f165bf59e553	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 08:34:15.11509	2025-11-26 08:34:14.995446	2025-11-26 08:34:14.995446
116	41e6e1ff-74ea-4a0d-91c4-03e4aefc8d65	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 08:40:12.619438	2025-11-26 08:40:12.473357	2025-11-26 08:40:12.473357
117	1498650b-8481-4545-9ab8-e29f19caf08d	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 08:42:10.637891	2025-11-26 08:42:10.49893	2025-11-26 08:42:10.49893
119	b6b65dda-cc2a-41d8-9b64-f49ef24f3514	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 09:12:54.934906	2025-11-26 09:12:54.964311	2025-11-26 09:12:54.964311
120	ce4bdcd8-b0c7-4cb5-8069-5f9c4d36f442	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 09:14:30.726773	2025-11-26 09:14:30.543446	2025-11-26 09:14:30.543446
121	3ad91b55-4ea3-42f6-83b2-7fd900083a03	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 09:49:58.228205	2025-11-26 09:49:58.005009	2025-11-26 09:49:58.005009
124	5d0337d2-c9be-44f0-9054-eb46071276d6	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 09:55:48.976975	2025-11-26 09:55:48.770567	2025-11-26 09:55:48.770567
128	bfc46bfb-d53a-44aa-9fce-bca85a32b6b3	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 10:18:00.006837	2025-11-26 10:17:59.796355	2025-11-26 10:17:59.796355
129	2ec7773a-f8cc-4412-80c1-6283c7a994c1	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 10:20:34.724345	2025-11-26 10:20:34.521563	2025-11-26 10:20:34.521563
118	d9ebd50e-481f-4847-87de-6d6b257f0ff5	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 08:54:32.776096	2025-11-26 08:54:32.615509	2025-11-26 08:54:32.615509
122	46c4bb01-6ec4-4b6c-86e5-85494bdb9b3b	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 09:50:26.779556	2025-11-26 09:50:26.5866	2025-11-26 09:50:26.5866
123	9a003691-8ccd-4cc8-9504-597c070cc2ee	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 09:55:17.907777	2025-11-26 09:55:17.663782	2025-11-26 09:55:17.663782
125	e5a4a66e-d30a-490c-9842-a5775cda5332	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 10:01:11.430038	2025-11-26 10:01:11.212401	2025-11-26 10:01:11.212401
126	475ef081-1093-44b0-9192-7aa49166ddb4	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 10:15:45.329098	2025-11-26 10:15:45.1006	2025-11-26 10:15:45.1006
127	ebe6e58f-bcd9-4437-b38b-284c0643be2c	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 10:17:26.210485	2025-11-26 10:17:25.950785	2025-11-26 10:17:25.950785
130	89d836f4-1a44-48f9-a4f0-0309c84de9b3	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 10:39:07.373826	2025-11-26 10:39:07.111645	2025-11-26 10:39:07.111645
131	b4c47205-eca1-4667-9332-b24c30eead51	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 10:54:51.847937	2025-11-26 10:54:51.615992	2025-11-26 10:54:51.615992
132	6f3965bf-7844-47f9-b85a-8d635d63e292	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 10:57:04.154982	2025-11-26 10:57:03.877745	2025-11-26 10:57:03.877745
133	770fe5d6-4953-4c9e-8e78-9cbe4d575517	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 11:01:48.538703	2025-11-26 11:01:48.239702	2025-11-26 11:01:48.239702
134	f7987cb2-f029-4d93-857a-d5106560b4e4	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 11:04:42.226135	2025-11-26 11:04:41.930408	2025-11-26 11:04:41.930408
135	2e144eec-51f7-47f2-a4eb-cc2d7280ebac	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 11:10:43.694737	2025-11-26 11:10:43.396671	2025-11-26 11:10:43.396671
136	0f2a6a6f-f7c2-4fc0-ac67-b9b8c754999e	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 11:13:07.178014	2025-11-26 11:13:06.87064	2025-11-26 11:13:06.87064
137	bf44eb15-d488-4108-8aa4-70679926e786	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 11:30:12.627627	2025-11-26 11:30:12.318306	2025-11-26 11:30:12.318306
138	fcfc7d70-de95-4515-bb91-b70f4c2dc942	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 11:30:30.377454	2025-11-26 11:30:30.047432	2025-11-26 11:30:30.047432
139	db018109-e244-4220-b335-b47c494093ea	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 11:39:40.511148	2025-11-26 11:39:40.176858	2025-11-26 11:39:40.176858
140	1f8a331a-4b5f-4746-8ba1-0b6722f59b52	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 11:49:53.876705	2025-11-26 11:49:53.538408	2025-11-26 11:49:53.538408
141	f2b74f9a-5734-4899-81e5-a77021127e73	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 11:54:50.517873	2025-11-26 11:54:50.351237	2025-11-26 11:54:50.351237
142	00120942-70b2-4450-978d-d3caec3e0cbe	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 12:02:03.915081	2025-11-26 12:02:03.556492	2025-11-26 12:02:03.556492
143	244edff2-0ff8-48ca-bd50-8184fb9d3722	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 12:16:45.828892	2025-11-26 12:16:45.458784	2025-11-26 12:16:45.458784
144	a19d202f-3f72-4484-b663-71b26d1dc9bd	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 12:31:33.266459	2025-11-26 12:31:32.895131	2025-11-26 12:31:32.895131
145	502f31ab-ed28-4a6b-ae4c-fb1a51466f4d	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 12:42:00.911159	2025-11-26 12:42:00.547747	2025-11-26 12:42:00.547747
146	e1ac652f-afcd-4fa8-8488-31616c96909f	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 12:57:36.187309	2025-11-26 12:57:35.805418	2025-11-26 12:57:35.805418
147	5eae4864-3a51-4fb7-8274-fc81d38e1b9c	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 13:01:28.766734	2025-11-26 13:01:28.386295	2025-11-26 13:01:28.386295
148	d46033cb-692d-4f74-86e2-c0c509cb88ad	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 13:06:41.047895	2025-11-26 13:06:40.655318	2025-11-26 13:06:40.655318
149	d427ec2c-7e50-4470-b0c1-dc10ddbe86a0	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 13:10:48.223229	2025-11-26 13:10:47.818751	2025-11-26 13:10:47.818751
150	bc1ba10e-c7a7-4f55-9953-dd9c95d623ad	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 13:23:21.671317	2025-11-26 13:23:21.259483	2025-11-26 13:23:21.259483
151	be54e5e4-cf36-49f4-8f83-017a38b52ba9	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 13:44:55.581652	2025-11-26 13:44:55.124417	2025-11-26 13:44:55.124417
152	062f4fc6-8e4b-4c9c-8785-384d30341478	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 13:55:21.543313	2025-11-26 13:55:21.081803	2025-11-26 13:55:21.081803
153	614919ad-e0ac-4975-a003-0a03e4383e60	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 14:29:57.498333	2025-11-26 14:29:57.095978	2025-11-26 14:29:57.095978
154	c9610919-0038-46e3-a3b7-56ae743e5269	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 14:33:39.345993	2025-11-26 14:33:38.845379	2025-11-26 14:33:38.845379
155	62008831-b970-4c31-80df-e56d40f3bd64	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 14:38:20.079653	2025-11-26 14:38:19.580705	2025-11-26 14:38:19.580705
156	bf85c053-a9d2-43b2-9493-129a7c2db1f1	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 14:41:57.690784	2025-11-26 14:41:57.194204	2025-11-26 14:41:57.194204
157	fb542994-3560-46d7-b5a5-935f529b9f7e	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 14:42:22.739886	2025-11-26 14:42:22.273116	2025-11-26 14:42:22.273116
158	7ef0891a-e29a-4a92-96fa-fcc1af688fc3	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 15:10:07.643534	2025-11-26 15:10:07.161133	2025-11-26 15:10:07.161133
159	8db261e8-d475-4fb5-9633-5f2e857e76f8	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 15:14:37.710162	2025-11-26 15:14:37.187638	2025-11-26 15:14:37.187638
160	8ddfc1dd-f96c-4491-8253-cbea813bd06d	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 15:17:39.149445	2025-11-26 15:17:38.625383	2025-11-26 15:17:38.625383
161	e1f44f0a-fe45-4f38-9cf5-5d56185d0fc1	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 15:22:01.319742	2025-11-26 15:22:00.779837	2025-11-26 15:22:00.779837
162	f938feab-8153-4f2b-8056-f6b73a5401ec	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 15:30:10.054841	2025-11-26 15:30:09.580869	2025-11-26 15:30:09.580869
163	ed419092-4767-475e-b995-884b4c7c7be1	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 15:39:17.828027	2025-11-26 15:39:17.315721	2025-11-26 15:39:17.315721
164	063e6cfc-e056-4abc-b278-fcae6c8c1134	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 15:45:44.560126	2025-11-26 15:45:44.016702	2025-11-26 15:45:44.016702
165	a9845882-08fb-45b5-b0e9-314bfe7cdffa	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 15:55:39.41592	2025-11-26 15:55:38.876946	2025-11-26 15:55:38.876946
166	a323486d-23a4-4cf7-8325-ed0cacc9065d	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 16:04:21.208174	2025-11-26 16:04:20.691861	2025-11-26 16:04:20.691861
167	3b277725-e184-4ec9-8d99-51022d068e89	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 17:44:31.260372	2025-11-26 09:44:31.681346	2025-11-26 09:44:31.681346
168	a8d910b9-4a18-42ce-a112-75bf912c4142	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 18:04:54.719686	2025-11-26 10:04:55.155674	2025-11-26 10:04:55.155674
172	8c3c6ae8-4516-462c-a71d-64452f948762	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 18:45:15.340364	2025-11-26 10:45:15.408981	2025-11-26 10:45:15.408981
174	3f08acf2-8a8b-4d8e-a1b4-dfc43cdc3a95	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-26 22:14:45.325416	2025-11-26 14:14:46.630376	2025-11-26 14:14:46.630376
181	8cd0eee5-35d7-4afe-963f-9f820f4a990e	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-26 22:34:38.889912	2025-11-26 14:34:39.206919	2025-11-26 14:34:39.206919
182	a600d346-e82a-4ab0-a48a-f9bff1c58951	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 23:30:58.445694	2025-11-26 15:30:59.165878	2025-11-26 15:30:59.165878
188	a7bafa70-0f9d-478e-8e55-c7737657e61d	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 00:32:08.594983	2025-11-26 16:32:09.34863	2025-11-26 16:32:09.34863
190	c639b54f-02b7-4497-9b2f-3ef4ac6b7305	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 00:34:36.850377	2025-11-26 16:34:37.584934	2025-11-26 16:34:37.584934
169	7b002f20-6648-44b3-b7b9-bac82d48d207	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 18:11:11.244195	2025-11-26 10:11:11.673755	2025-11-26 10:11:11.673755
170	4b47f97d-a23d-4c01-b539-c087d1ba193b	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 18:34:22.125773	2025-11-26 10:34:22.124429	2025-11-26 10:34:22.124429
171	73c00ed7-0fff-4ca9-8df0-bb87c405f7aa	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 18:36:06.469848	2025-11-26 10:36:06.453216	2025-11-26 10:36:06.453216
173	15cdd093-f3eb-45ce-a981-1f99d76c3c66	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 18:46:49.626737	2025-11-26 10:46:49.619699	2025-11-26 10:46:49.619699
176	f27f30a3-bf15-4ed5-916f-e1b6625a52de	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-26 22:23:39.705628	2025-11-26 14:23:39.992418	2025-11-26 14:23:39.992418
178	0f2a1732-4a7e-4044-ba7b-950000bf3601	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-26 22:30:47.993899	2025-11-26 14:30:48.428994	2025-11-26 14:30:48.428994
179	fc6357af-35f6-494e-a92e-c61e7bb2a3ef	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-26 22:33:33.034856	2025-11-26 14:33:33.367185	2025-11-26 14:33:33.367185
180	af38047c-791b-4f9f-aaea-e4ae51c0e0bc	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-26 22:34:24.23376	2025-11-26 14:34:24.51355	2025-11-26 14:34:24.51355
183	acb3ccbf-ff7c-4ee8-a2ea-50d086af3d91	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 23:36:57.886108	2025-11-26 15:36:58.662291	2025-11-26 15:36:58.662291
184	8fde60c5-4fea-4b25-9ac9-42bd4625259e	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 23:46:31.455806	2025-11-26 15:46:32.154238	2025-11-26 15:46:32.154238
185	9c6d3e68-0243-4398-8895-0d7d52643e61	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-26 23:51:27.423598	2025-11-26 15:51:28.317616	2025-11-26 15:51:28.317616
186	4d04ba25-6549-4f5f-8d41-7977935e3043	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 00:13:11.98575	2025-11-26 16:13:12.688338	2025-11-26 16:13:12.688338
187	cd7a0bbb-117a-4b2c-a796-53c5dc3182e4	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 00:26:36.299425	2025-11-26 16:26:36.98912	2025-11-26 16:26:36.98912
189	24cb1926-a40c-4a13-abcd-9133499fbede	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 00:33:48.894818	2025-11-26 16:33:49.575266	2025-11-26 16:33:49.575266
191	ce5539c2-af05-426d-9dca-ea751b13c12c	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 01:35:44.530158	2025-11-26 17:35:44.833922	2025-11-26 17:35:44.833922
192	2e8f2c28-7712-40de-bf76-bbeebd342826	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 01:53:34.572644	2025-11-26 17:53:35.270329	2025-11-26 17:53:35.270329
193	2d8ed79f-ddc8-4680-a80e-043f38d2bcc7	223.77.17.251	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 02:51:37.293703	2025-11-26 18:51:37.245727	2025-11-26 18:51:37.245727
194	010bea85-2db6-432d-a07c-0ccc398fa8e5	39.144.110.130	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "AQ3A.240912.001", "number_of_processors": 8}	2025-11-27 03:17:41.227332	2025-11-26 19:17:41.908253	2025-11-26 19:17:41.908253
195	47d7d1a7-3d7a-4026-b696-0f005f64f4b4	112.38.98.182	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "AQ3A.240912.001", "number_of_processors": 8}	2025-11-27 03:38:05.790552	2025-11-26 19:38:06.422434	2025-11-26 19:38:06.422434
196	8c9c3847-4ac1-4fe6-8292-77fb565e82d9	112.38.98.182	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "AQ3A.240912.001", "number_of_processors": 8}	2025-11-27 03:38:10.023347	2025-11-26 19:38:10.648904	2025-11-26 19:38:10.648904
197	fbc197c3-a5eb-4814-bdaa-7083c08d0a48	112.38.98.182	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "AQ3A.240912.001", "number_of_processors": 8}	2025-11-27 03:40:33.859169	2025-11-26 19:40:34.487891	2025-11-26 19:40:34.487891
198	57d982a3-2288-4d6d-9830-05035a45ca7e	112.38.98.182	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "AQ3A.240912.001", "number_of_processors": 8}	2025-11-27 03:41:50.985011	2025-11-26 19:41:51.612486	2025-11-26 19:41:51.612486
199	8eda76f1-8438-401c-9fbd-b637448fcc02	112.38.98.182	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "AQ3A.240912.001", "number_of_processors": 8}	2025-11-27 03:45:11.114979	2025-11-26 19:45:11.733291	2025-11-26 19:45:11.733291
177	9e758d9b-dbef-4d55-a570-3412d854567c	112.38.98.182	windows	{"os": "windows", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "\\"Windows 10 Pro\\" 10.0 (Build 22631)", "number_of_processors": 20}	2025-11-26 22:30:06.854483	2025-11-26 14:30:00.925065	2025-12-03 21:32:25.109366
200	6e1edffa-370e-406b-9eae-a72f9f0bbfcc	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-27 13:58:42.822706	2025-11-27 05:58:43.176598	2025-11-27 05:58:43.176598
201	cfef3c6a-c7f9-4cdf-8151-4218cfb68f39	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-27 13:59:22.508376	2025-11-27 05:59:22.860519	2025-11-27 05:59:22.860519
4	682fa00e-43d7-4218-b110-e17e7d84b5d3	117.154.120.81	windows	{"os": "windows", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "\\"Windows 10 Pro\\" 10.0 (Build 19045)", "number_of_processors": 16}	2025-11-24 17:03:53.236877	2025-11-24 17:03:54.632007	2025-11-28 00:36:31.143976
175	29d8f84c-09a1-417b-a6f1-002b20b2ab03	103.241.103.162	windows	{"os": "windows", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "\\"Windows 10 Home China\\" 10.0 (Build 26100)", "number_of_processors": 32}	2025-11-26 22:20:54.120838	2025-11-26 14:20:54.423493	2025-12-05 21:24:08.642224
202	087efefc-f167-4f8b-91ac-2cd710f486a0	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-27 13:59:31.440273	2025-11-27 05:59:31.894246	2025-11-27 05:59:31.894246
204	cdd114fb-25eb-4d7b-b1af-5f9cc3745194	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 14:24:19.356728	2025-11-27 06:24:20.216111	2025-11-27 06:24:20.216111
207	da3a6125-c093-4afb-b549-f27597c9db52	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 20:00:34.772118	2025-11-27 12:00:34.336616	2025-11-27 12:00:34.336616
203	a1237997-29b1-4506-bf89-d7e097ccfff3	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 14:14:44.07519	2025-11-27 06:14:43.899898	2025-11-27 06:14:43.899898
205	c4b46105-8061-4da5-b828-071307c8a8b7	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 14:58:47.715508	2025-11-27 06:58:47.291015	2025-11-27 06:58:47.291015
206	d03fba2a-482f-4fb0-88ae-23ffdd299f49	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 19:46:23.014859	2025-11-27 11:46:22.586722	2025-11-27 11:46:22.586722
208	e567f64e-f7fb-481a-952e-698a4c3efe62	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 21:07:09.273109	2025-11-27 13:07:09.239617	2025-11-27 13:07:09.239617
209	0c579094-6c31-48ff-92ca-da1535b60952	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 21:26:46.28413	2025-11-27 13:26:45.838829	2025-11-27 13:26:45.838829
210	8fe34b81-7cf1-45a1-9268-8c231e7fd2ff	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-27 22:24:05.035639	2025-11-27 14:24:04.603098	2025-11-27 14:24:04.603098
211	056c6300-53ea-4772-a18d-8efe1cc7978b	45.199.128.185	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-27 23:47:18.568788	2025-11-27 15:47:18.908292	2025-11-27 15:47:18.908292
212	ba09bea2-0756-4710-8e09-8fb6caca3657	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-28 00:52:46.380213	2025-11-27 16:52:46.710314	2025-11-27 16:52:46.710314
213	08587245-8456-404a-8fca-d1dda38fe181	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-28 00:55:25.994676	2025-11-27 16:55:26.399737	2025-11-27 16:55:26.399737
214	932ab653-4255-4f5f-a1d5-f2eb0cdf649b	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-28 00:56:55.095067	2025-11-27 16:56:55.489626	2025-11-27 16:56:55.489626
215	29c66954-8486-4d74-a5bd-27797bf8bee1	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-28 13:46:06.351002	2025-11-28 05:46:06.807639	2025-11-28 05:46:06.807639
216	29fe8cad-a02c-41c8-b66a-b348adcca48b	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-28 13:50:59.798485	2025-11-28 05:50:59.249081	2025-11-28 05:50:59.249081
217	9a00334e-6397-431f-b701-00c4175eee01	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-28 14:09:07.90417	2025-11-28 06:09:07.803309	2025-11-28 06:09:07.803309
218	c5cba707-54fb-4fd0-960f-6e12aa0a2e4f	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-28 14:38:47.197038	2025-11-28 06:38:47.041785	2025-11-28 06:38:47.041785
219	e2cb493f-2009-4e68-a1b1-77e27f2e33f8	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-28 14:40:43.149241	2025-11-28 06:40:43.023892	2025-11-28 06:40:43.023892
220	11b30515-93e4-4127-9156-eb8eddfaef5d	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-28 15:00:09.554078	2025-11-28 07:00:09.37547	2025-11-28 07:00:09.37547
221	8c46bf2c-e6e6-4778-8be0-3f7e20a9e744	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-28 15:02:23.038472	2025-11-28 07:02:22.860473	2025-11-28 07:02:22.860473
222	85fdfa17-3d8c-482c-a8df-20879853b4b2	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-28 15:08:02.193946	2025-11-28 07:08:02.045696	2025-11-28 07:08:02.045696
223	1974e6b0-b1d1-4d93-9230-9e381c4423a3	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-28 15:56:36.115882	2025-11-28 07:56:35.579204	2025-11-28 07:56:35.579204
224	82d9183a-9c86-4b98-94b6-277f742b6591	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-28 15:58:40.113023	2025-11-28 07:58:40.586031	2025-11-28 07:58:40.586031
225	d3272912-2b27-4b8f-944c-bec1b2aec649	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-28 15:59:02.568035	2025-11-28 07:59:03.009289	2025-11-28 07:59:03.009289
226	7d798b07-dbcc-489b-aa52-edb81e5ddc80	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-28 15:59:36.153986	2025-11-28 07:59:36.550005	2025-11-28 07:59:36.550005
227	99143ea8-f6b0-4dc4-97b3-1ac5f8a7db34	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-28 16:07:10.284911	2025-11-28 08:07:09.722247	2025-11-28 08:07:09.722247
228	ab39132a-67e8-40bb-808b-0ab0e5ced6fa	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-28 16:07:20.715291	2025-11-28 08:07:20.159407	2025-11-28 08:07:20.159407
229	8afe044d-d6fc-49bc-8b7c-6cf51ba8c5a0	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-28 18:59:37.313957	2025-11-28 10:59:37.328015	2025-11-28 10:59:37.328015
230	5f67f3fc-64f6-4b70-b476-84f6f884dd7a	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-28 21:57:07.333755	2025-11-28 13:57:07.742579	2025-11-28 13:57:07.742579
231	6ed3a670-7f00-44e3-a65e-bdfbda926a3b	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-28 21:58:03.428565	2025-11-28 13:58:03.859303	2025-11-28 13:58:03.859303
232	3193f298-5acb-4b5e-9620-756543eced22	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-28 21:59:55.313204	2025-11-28 13:59:55.714207	2025-11-28 13:59:55.714207
233	c40aafb7-cec2-4800-97fc-ff36c5cd320a	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-29 08:44:30.355283	2025-11-29 00:44:30.236394	2025-11-29 00:44:30.236394
234	037af4b6-6531-4082-84da-4f2872eeb6a8	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-29 11:15:47.673503	2025-11-29 03:15:47.790669	2025-11-29 03:15:47.790669
235	ca11699f-4d94-4410-af77-bbd9a678571b	125.80.220.55	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "PQ3B.190801.08071126 release-keys", "number_of_processors": 4}	2025-11-29 11:50:08.753834	2025-11-29 03:50:08.853745	2025-11-29 03:50:08.853745
237	bf8bdc13-e488-4c23-9a32-4411b0e4b0f6	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-29 23:45:38.796673	2025-11-29 23:45:38.547176	2025-11-29 23:45:38.547176
249	4dfec9fc-6283-494b-b659-24e85234a8f6	219.142.153.115	windows	{"os": "windows", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "\\"Windows 10 Home China\\" 10.0 (Build 26100)", "number_of_processors": 16}	2025-12-02 20:27:09.459991	2025-12-02 20:27:09.931516	2025-12-05 15:30:34.586683
238	5f897a33-cea6-4f92-9c8e-edc5c6032322	125.80.220.55	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "HMA-AL00 10.1.0.163(C00E160R1P8)", "number_of_processors": 8}	2025-11-30 14:39:07.961096	2025-11-30 14:39:07.482885	2025-11-30 14:39:07.482885
239	012b0691-3616-4481-bf70-cbe61ba515e7	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-11-30 14:41:16.072498	2025-11-30 14:41:16.027472	2025-11-30 14:41:16.027472
240	6e4a877b-67ac-4766-b400-2283e5bf06ff	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-11-30 17:45:59.344832	2025-11-30 17:45:59.894548	2025-11-30 17:45:59.894548
241	edd124cf-439e-45dc-ab7f-8b1e08b0c236	113.248.107.238	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "HMA-AL00 10.1.0.163(C00E160R1P8)", "number_of_processors": 8}	2025-12-01 10:23:24.945884	2025-12-01 10:23:24.14207	2025-12-01 10:23:24.14207
242	3efe4e9e-9e79-4f39-8005-d7c7c938ed2b	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-12-01 10:34:56.318774	2025-12-01 10:34:56.871234	2025-12-01 10:34:56.871234
243	21505c3e-1695-49dd-9259-968a13818ca1	113.248.107.238	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "PQ3B.190801.08071126 release-keys", "number_of_processors": 4}	2025-12-01 10:52:17.990286	2025-12-01 10:52:18.229669	2025-12-01 10:52:18.229669
236	f25f8b56-b068-48e1-b34b-2189a6cca76b	125.80.215.120	windows	{"os": "windows", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "\\"Windows 10 Home China\\" 10.0 (Build 26200)", "number_of_processors": 12}	2025-11-29 13:05:28.225376	2025-11-29 05:06:10.470761	2025-12-11 11:48:54.17449
244	4b7696e9-e827-4e86-b21d-c47ed991193d	183.227.175.28	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "HMA-AL00 10.1.0.163(C00E160R1P8)", "number_of_processors": 8}	2025-12-01 22:18:22.778118	2025-12-01 22:18:21.804389	2025-12-01 22:18:21.804389
245	d0818abb-05ea-4562-8ad4-5fb75e7bb345	113.248.107.238	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "PQ3B.190801.08071126 release-keys", "number_of_processors": 4}	2025-12-01 22:34:52.560553	2025-12-01 22:34:53.479902	2025-12-01 22:34:53.479902
246	0d8b75f1-9739-4f45-a638-4188ecae3c41	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-12-02 13:20:15.360247	2025-12-02 13:20:15.988097	2025-12-02 13:20:15.988097
247	1d8da976-c80c-49f9-ad0f-bf605e0c4cfa	183.227.245.229	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "HMA-AL00 10.1.0.163(C00E160R1P8)", "number_of_processors": 8}	2025-12-02 20:26:40.576257	2025-12-02 20:26:39.21951	2025-12-02 20:26:39.21951
248	7f638861-3a78-4391-805f-9699d0b2a5b6	113.248.107.238	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "PQ3B.190801.08071126 release-keys", "number_of_processors": 4}	2025-12-02 20:26:47.499517	2025-12-02 20:26:51.819194	2025-12-02 20:26:51.819194
250	69a0fcdb-9ff4-4e14-a0c3-f766452feb5d	113.248.107.238	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "PQ3B.190801.08071126 release-keys", "number_of_processors": 4}	2025-12-02 20:50:32.41686	2025-12-02 20:50:37.168905	2025-12-02 20:50:37.168905
251	6eca18b6-f35f-463f-a94a-a289aab1729a	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-12-02 20:55:49.721421	2025-12-02 20:55:48.990594	2025-12-02 20:55:48.990594
252	114c85ae-dea7-4985-8bef-03aa6f8d4688	183.227.245.229	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "HMA-AL00 10.1.0.163(C00E160R1P8)", "number_of_processors": 8}	2025-12-02 21:00:21.976544	2025-12-02 21:00:20.906784	2025-12-02 21:00:20.906784
253	79b0380a-ae45-4a6b-94ee-3c608556dba9	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-12-03 21:27:00.281327	2025-12-03 21:27:01.067504	2025-12-03 21:27:01.067504
254	d785ce88-2321-4251-bf5c-586594501f37	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-12-03 21:46:50.29011	2025-12-03 21:46:49.450289	2025-12-03 21:46:49.450289
255	436bd176-504a-4cf0-b8d1-e5e05337dcd3	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-12-04 00:34:44.54908	2025-12-04 00:34:45.326215	2025-12-04 00:34:45.326215
256	3f36e071-04d4-45bd-9df6-b490af88f87d	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "AP3A.240905.015.A2.F9460ZCS7EYI1", "number_of_processors": 8}	2025-12-04 00:46:14.853627	2025-12-04 00:46:14.953809	2025-12-04 00:46:14.953809
257	e85e5fbb-2cc9-4876-b2f8-adf27455cb57	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-12-04 14:58:58.634206	2025-12-04 14:58:59.448529	2025-12-04 14:58:59.448529
258	bdb455b4-0d1d-4d8b-a809-dccb91330674	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-12-05 11:39:50.952831	2025-12-05 11:39:51.857564	2025-12-05 11:39:51.857564
259	ef863540-229a-4c58-b800-340f8877f4b6	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-12-05 11:40:58.899843	2025-12-05 11:40:59.795442	2025-12-05 11:40:59.795442
260	c76aa53a-0e32-4255-b55b-83cb9005a867	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-12-05 11:41:36.39141	2025-12-05 11:41:37.279521	2025-12-05 11:41:37.279521
261	19865c07-2725-465a-8221-ac2806f8fa9a	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-12-05 11:42:56.051246	2025-12-05 11:42:56.966707	2025-12-05 11:42:56.966707
262	6fa791d5-27d2-4a4c-9279-3b99a5dfabc9	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-12-05 12:02:03.853225	2025-12-05 12:02:03.348174	2025-12-05 12:02:03.348174
263	81177425-8332-43fe-ba3a-d9d212bd25bb	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-12-05 12:10:29.513674	2025-12-05 12:10:30.408698	2025-12-05 12:10:30.408698
264	2ec1f5a0-e011-4972-8cc9-91d8e4de218e	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-12-05 12:12:20.396377	2025-12-05 12:12:19.883926	2025-12-05 12:12:19.883926
265	8744f8b2-c6da-40ec-8c66-50ab501e5ec8	113.250.144.118	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "PQ3B.190801.08071126 release-keys", "number_of_processors": 4}	2025-12-05 15:31:46.706709	2025-12-05 15:31:54.055562	2025-12-05 15:31:54.055562
266	3d40ef93-6c53-444d-b343-cd5831b247e7	219.142.153.115	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "HMA-AL00 10.1.0.163(C00E160R1P8)", "number_of_processors": 8}	2025-12-05 15:44:39.395094	2025-12-05 15:44:40.083452	2025-12-05 15:44:40.083452
267	035e2d1f-5cc4-486b-b3e9-34db4f284302	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-12-05 18:47:26.616353	2025-12-05 18:47:27.50854	2025-12-05 18:47:27.50854
268	7d54e003-43c7-4d77-9096-9e8a3229399b	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-12-05 20:16:56.74758	2025-12-05 20:16:56.194384	2025-12-05 20:16:56.194384
269	fe9a77a1-c987-4d1c-beb7-4aa6b2dac9c1	112.38.98.182	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "AQ3A.240912.001", "number_of_processors": 8}	2025-12-05 21:01:28.054628	2025-12-05 21:01:28.064548	2025-12-05 21:01:28.064548
270	a3f2cfc3-138d-40b2-8424-f04aef1ab896	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-12-05 21:15:31.385433	2025-12-05 21:15:32.285549	2025-12-05 21:15:32.285549
271	a6f64ac4-abd4-4e50-a47d-6df3b176bf30	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-12-06 00:57:16.606145	2025-12-06 00:57:15.99687	2025-12-06 00:57:15.99687
272	474c29a7-9e7a-4884-9141-46d3c1733dcc	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-12-06 01:12:41.44917	2025-12-06 01:12:40.832394	2025-12-06 01:12:40.832394
273	7e398df9-9c87-43b6-a792-e7f2bb52efd9	103.241.103.162	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "RedMagicOS11.0.13MR2", "number_of_processors": 8}	2025-12-06 09:16:50.510769	2025-12-06 09:16:51.401627	2025-12-06 09:16:51.401627
274	4e4bd0d5-9cb0-4940-9791-5a971b0c8f3a	129.224.202.243	windows	{"os": "windows", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "\\"Windows 10 Enterprise\\" 10.0 (Build 19045)", "number_of_processors": 4}	2025-12-06 10:19:10.023759	2025-12-06 10:20:03.868737	2025-12-06 10:20:03.868737
275	e13c5c20-b994-4420-b892-0402616223d1	129.224.203.145	windows	{"os": "windows", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "\\"Windows 10 Home China\\" 10.0 (Build 26100)", "number_of_processors": 16}	2025-12-06 10:21:07.28045	2025-12-06 10:21:08.788186	2025-12-06 10:21:08.788186
276	646b9941-ab81-4ddf-9dad-3261e242979b	129.224.202.101	windows	{"os": "windows", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "\\"Windows 10 Pro\\" 10.0 (Build 26200)", "number_of_processors": 32}	2025-12-06 10:21:18.664582	2025-12-06 10:21:19.698564	2025-12-06 10:21:19.698564
277	635fe834-4247-4279-8826-206b09691d50	129.224.202.101	windows	{"os": "windows", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "\\"Windows 10 Enterprise\\" 10.0 (Build 19045)", "number_of_processors": 4}	2025-12-06 10:22:12.501319	2025-12-06 10:22:14.843174	2025-12-06 10:22:14.843174
278	3f9cd572-93ac-4531-bdde-7803a113052e	129.224.203.208	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "TP1A.220624.014", "number_of_processors": 8}	2025-12-06 10:29:57.395718	2025-12-06 10:29:57.126703	2025-12-06 10:29:57.126703
279	0bca375f-4e8e-436d-a43f-8c26569cb07c	112.57.79.240	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "ALT-AN10 8.0.0.612(C00E601R301P4)", "number_of_processors": 8}	2025-12-06 10:31:34.257051	2025-12-06 10:31:33.27719	2025-12-06 10:31:33.27719
280	ff2cc286-74c8-41a2-99cf-96952efea460	129.224.203.145	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "RMO-TN00 7.0.0.210(C01E189R6P6)", "number_of_processors": 8}	2025-12-06 10:34:02.3414	2025-12-06 10:34:02.31276	2025-12-06 10:34:02.31276
281	3c323cb0-4c79-453a-9589-6653ce40c642	129.224.203.208	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "ALT-AN10 8.0.0.612(C00E601R104P1)", "number_of_processors": 8}	2025-12-06 10:41:52.027188	2025-12-06 10:41:51.701744	2025-12-06 10:41:51.701744
282	cf841592-3f4a-4421-a23a-ebfd27a9d6fb	112.38.98.182	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "AQ3A.240912.001", "number_of_processors": 8}	2025-12-06 14:53:11.213541	2025-12-06 14:53:11.342805	2025-12-06 14:53:11.342805
283	906e4c39-fda6-44d3-9b37-0cad8db1589a	112.38.98.182	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "PD2055_A_9.10.3", "number_of_processors": 8}	2025-12-06 14:53:28.890262	2025-12-06 14:53:29.016087	2025-12-06 14:53:29.016087
284	43dedf82-2fc0-4594-9070-f26c724d7a33	112.38.98.182	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "AQ3A.240912.001", "number_of_processors": 8}	2025-12-06 15:06:30.352537	2025-12-06 15:06:30.503131	2025-12-06 15:06:30.503131
285	4496f934-e385-4206-91a7-c1742a0dbe10	112.38.98.182	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "PD2055_A_9.10.3", "number_of_processors": 8}	2025-12-06 15:06:40.358335	2025-12-06 15:06:40.473648	2025-12-06 15:06:40.473648
286	8e621a97-9c70-4189-82be-a6ec623a6239	117.154.120.81	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-12-06 15:09:14.367866	2025-12-06 15:09:13.640602	2025-12-06 15:09:13.640602
287	f5e54147-385c-40d7-a234-4ab2a023517f	129.224.203.208	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "ALT-AN10 8.0.0.612(C00E601R104P1)", "number_of_processors": 8}	2025-12-07 12:20:18.272542	2025-12-07 12:20:17.844784	2025-12-07 12:20:17.844784
288	ba0b671e-39e7-46b5-b700-fb802e8110a0	129.224.203.242	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "RMO-TN00 7.0.0.210(C01E189R6P6)", "number_of_processors": 8}	2025-12-07 12:57:53.95025	2025-12-07 12:57:53.865309	2025-12-07 12:57:53.865309
289	79c41975-0485-47d2-9a75-ed330fd250c8	129.224.203.208	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "TP1A.220624.014", "number_of_processors": 8}	2025-12-07 13:10:01.079191	2025-12-07 13:10:01.346179	2025-12-07 13:10:01.346179
290	85741e2c-d364-4448-81b6-383ffa54a2b7	129.224.202.78	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "RMO-TN00 7.0.0.210(C01E189R6P6)", "number_of_processors": 8}	2025-12-07 13:10:28.919	2025-12-07 13:10:28.973633	2025-12-07 13:10:28.973633
291	84a91b4f-f21f-493c-ab67-ae718094080b	112.57.79.240	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "ALT-AN10 8.0.0.612(C00E601R301P4)", "number_of_processors": 8}	2025-12-07 13:12:08.893385	2025-12-07 13:12:08.804508	2025-12-07 13:12:08.804508
292	e1fc009a-413a-49a7-92fe-9068923502b2	125.80.215.120	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "HMA-AL00 10.1.0.163(C00E160R1P8)", "number_of_processors": 8}	2025-12-11 11:46:52.677133	2025-12-11 11:46:52.896763	2025-12-11 11:46:52.896763
293	09c0ba0e-e228-4258-842d-20a7679944f5	125.80.215.120	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "PQ3B.190801.08071126 release-keys", "number_of_processors": 4}	2025-12-11 12:08:43.70455	2025-12-11 12:08:43.791414	2025-12-11 12:08:43.791414
294	6f167592-8d69-423d-9b6b-b59e16e075a8	223.77.17.174	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-12-12 10:43:22.816708	2025-12-12 10:43:21.892563	2025-12-12 10:43:21.892563
295	7b2fc8fd-41f6-45ec-ac6d-efed1a492448	150.228.149.175	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "ALT-AN10 8.0.0.612(C00E601R301P4)", "number_of_processors": 8}	2025-12-13 09:36:17.805847	2025-12-13 09:36:17.141219	2025-12-13 09:36:17.141219
296	fd5ad9d7-b4fb-4a51-99d7-1d68ea2554ba	150.228.148.20	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "BRC-AN00 9.0.0.200(C00E170R301P5)", "number_of_processors": 8}	2025-12-13 09:42:18.049372	2025-12-13 09:42:13.470747	2025-12-13 09:42:13.470747
297	82e3998d-0519-4f8c-b21c-fed0bd6b9623	129.224.203.248	windows	{"os": "windows", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "\\"Windows 10 Enterprise\\" 10.0 (Build 19045)", "number_of_processors": 4}	2025-12-13 10:25:46.733223	2025-12-13 10:25:55.283275	2025-12-13 10:25:55.283275
298	d196c61e-33ab-4205-a365-d6b96b29cfe0	117.154.120.11	windows	{"os": "windows", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "\\"Windows 10 Pro\\" 10.0 (Build 19045)", "number_of_processors": 16}	2025-12-13 19:56:37.758009	2025-12-13 19:56:39.337103	2025-12-13 19:56:39.337103
299	2c220ead-bfdc-45a1-b389-df1cccd63643	117.154.120.11	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-12-13 20:12:27.015188	2025-12-13 20:12:27.299993	2025-12-13 20:12:27.299993
300	801adfce-aea6-4e2e-b820-517cd83ab9e8	150.228.148.20	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "TP1A.220624.014", "number_of_processors": 8}	2025-12-14 10:03:22.324648	2025-12-14 10:03:21.967373	2025-12-14 10:03:21.967373
301	24ba8b73-861a-4b0c-b873-a36dd80c78ab	129.224.203.176	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "BRC-AN00 9.0.0.200(C00E170R301P5)", "number_of_processors": 8}	2025-12-14 10:05:54.084268	2025-12-14 10:05:50.560085	2025-12-14 10:05:50.560085
302	156077e7-81a9-41ac-8eb6-db20477e0aa8	112.19.198.177	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "BRC-AN00 9.0.0.188(SP3C00E163R104P5)", "number_of_processors": 8}	2025-12-14 10:18:01.626747	2025-12-14 10:18:02.278713	2025-12-14 10:18:02.278713
303	a818953b-6497-4d1d-9bf0-c1b182c9dc6b	150.228.149.175	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "ALT-AN10 8.0.0.612(C00E601R301P4)", "number_of_processors": 8}	2025-12-14 10:24:28.029354	2025-12-14 10:24:27.13947	2025-12-14 10:24:27.13947
304	4db656b5-c94f-4bbe-bf62-0fe5697e7ccc	150.228.148.20	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "ALT-AN10 8.0.0.612(C00E601R104P1)", "number_of_processors": 8}	2025-12-14 10:29:51.076215	2025-12-14 10:29:44.754154	2025-12-14 10:29:44.754154
306	f0ad201c-4722-4fa4-96bf-6b534b31dff2	113.248.107.208	android	{"os": "android", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "PQ3B.190801.08071126 release-keys", "number_of_processors": 4}	2025-12-14 13:47:22.274865	2025-12-14 13:47:22.456116	2025-12-14 13:47:22.456116
307	69463f93-be79-4164-9322-712da794453c	113.248.107.208	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "HMA-AL00 10.1.0.163(C00E160R1P8)", "number_of_processors": 8}	2025-12-14 13:51:05.859332	2025-12-14 13:51:05.007999	2025-12-14 13:51:05.007999
305	f1f119ca-9e4b-4ac4-9325-4a99835e4469	113.248.107.208	windows	{"os": "windows", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "\\"Windows 10 Home China\\" 10.0 (Build 26200)", "number_of_processors": 12}	2025-12-14 13:24:00.690217	2025-12-14 13:24:58.583422	2025-12-14 16:04:49.606422
308	e4615b8f-3d55-4f28-8b41-0d669a049e21	111.41.17.48	windows	{"os": "windows", "is_web": false, "locale": "zh_CN", "is_debug": false, "os_version": "\\"Windows 10 Home China\\" 10.0 (Build 19045)", "number_of_processors": 12}	2025-12-15 11:47:53.669603	2025-12-15 11:47:57.01135	2025-12-15 11:47:57.01135
309	59194441-ce0b-4e11-8729-940c06784c4f	117.154.120.11	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-12-16 11:17:29.5578	2025-12-16 11:17:29.234901	2025-12-16 11:17:29.234901
310	d2670d72-87ba-449f-ab11-d340abfa1d85	117.154.120.11	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": false, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2025-12-16 11:20:45.586586	2025-12-16 11:20:45.280477	2025-12-16 11:20:45.280477
311	514ad2d4-7fa9-4344-86d0-a7977f36f014	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2025-12-18 10:09:05.703718	2025-12-18 10:09:05.994695	2025-12-18 12:41:20.206487
312	53d87d66-ba39-4667-92fe-2ed954f0f8a2	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2025-12-19 09:39:07.07418	2025-12-19 09:39:07.445219	2025-12-19 09:39:07.445219
313	6146efe4-72f0-4147-98cc-f1cd4205955f	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2025-12-19 09:50:06.54965	2025-12-19 09:50:06.77318	2025-12-19 09:50:06.77318
314	c9fbc4a0-76fb-4974-89b8-cfa7c9a6a15f	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2025-12-19 10:09:27.518209	2025-12-19 10:09:27.738882	2025-12-19 10:09:27.738882
315	fd031741-084c-43e3-af49-ee48252a8af9	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2025-12-19 10:47:07.283369	2025-12-19 10:47:07.509861	2025-12-19 10:47:07.509861
317	bb13be8a-4513-4b73-8eb7-38faddb9123f	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2025-12-19 20:49:36.913296	2025-12-19 20:49:37.245391	2025-12-19 20:49:37.245391
318	d6386335-ea70-44af-8d94-9d282692ee50	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2025-12-19 22:13:47.045697	2025-12-19 22:13:47.274573	2025-12-19 22:13:47.274573
319	ab584270-9d2a-4f28-ba47-13f354819dfb	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2025-12-29 20:40:16.404455	2025-12-29 20:40:16.633432	2025-12-29 20:40:16.633432
320	0101cd54-6f7c-49a5-9a3c-ff4fde1b15a6	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2026-01-09 12:08:02.907596	2026-01-09 12:08:03.1803	2026-01-09 12:08:03.1803
321	d6ec8aea-931a-47fa-a2d0-d1bc15b72bf6	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2026-01-09 12:46:42.724943	2026-01-09 12:46:42.957201	2026-01-09 12:46:42.957201
322	1e6b8f4e-6703-417e-a408-a74e11f5e9d6	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2026-01-09 16:34:54.174642	2026-01-09 08:34:54.47082	2026-01-09 08:34:54.47082
323	5b18a6b7-4bb9-4a82-8353-d0a914ffac06	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2026-01-09 17:05:00.089819	2026-01-09 17:05:00.318309	2026-01-09 17:05:00.318309
324	926d03cb-7eff-47a7-861b-20b85ecaec25	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2026-01-23 21:18:30.476602	2026-01-23 21:18:30.706661	2026-01-23 21:18:30.706661
325	cb4e28d3-ec41-4c6d-953e-2f6ac8081b75	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2026-02-27 21:11:21.573123	2026-02-27 13:11:21.819169	2026-02-27 13:11:21.819169
326	5f0bf85e-d7e2-474c-9d44-f0fd748e1e1d	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2026-02-28 13:15:40.602391	2026-02-28 05:15:40.849527	2026-02-28 05:15:40.849527
327	3a1d7489-d78e-4649-bb7a-75b95a8c6e78	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2026-03-01 13:46:01.220172	2026-03-01 13:46:01.475227	2026-03-01 13:46:01.475227
328	d2452de5-6a25-401a-95c5-bc1cee03f146	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2026-03-01 14:51:50.288494	2026-03-01 06:51:50.555741	2026-03-01 06:51:50.555741
329	1cd7eaf0-9018-4f40-829b-9b234c2966dc	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2026-03-01 14:52:34.535298	2026-03-01 06:52:34.791325	2026-03-01 06:52:34.791325
330	248c9c33-91d1-4aa0-a253-31590bb6517b	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2026-06-27 12:58:13.166138	2026-06-27 12:58:14.455114	2026-06-27 12:58:14.455114
331	bf8b4351-4518-4076-bd31-ee8426808b38	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2026-06-27 21:07:26.301333	2026-06-27 13:07:27.334597	2026-06-27 13:07:27.334597
332	2ecb7652-eec1-4e7d-85ee-690a0e2e0a05	192.168.1.7	android	{"os": "android", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "GLK-AL00 3.0.0.168(C00E160R1P3)", "number_of_processors": 8}	2026-07-02 08:59:06.77306	2026-07-02 08:59:06.145312	2026-07-02 08:59:06.145312
316	5ab3656a-b98c-4fa1-a54a-ea9d900b13b4	192.168.1.20	ios	{"os": "ios", "is_web": false, "locale": "zh_Hans_CN", "is_debug": true, "os_version": "Version 18.4 (Build 22E238)", "number_of_processors": 16}	2025-12-19 14:38:14.867039	2025-12-19 14:38:15.101958	2026-07-03 09:19:26.046802
\.


--
-- Data for Name: favorite_contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.favorite_contacts (id, user_id, contact_id, created_at) FROM stdin;
\.


--
-- Data for Name: favorite_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.favorite_groups (id, user_id, group_id, created_at) FROM stdin;
\.


--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.favorites (id, user_id, message_id, content, message_type, file_name, sender_id, sender_name, created_at, server_id, sync_status) FROM stdin;
\.


--
-- Data for Name: file_assistant_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_assistant_messages (id, user_id, content, message_type, file_name, quoted_message_id, quoted_message_content, status, created_at, server_id) FROM stdin;
\.


--
-- Data for Name: group_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.group_members (id, group_id, user_id, nickname, remark, role, joined_at, is_muted, approval_status, do_not_disturb) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.groups (id, name, announcement, avatar, owner_id, created_at, updated_at, deleted_at, all_muted, invite_confirmation, admin_only_edit_name, member_view_permission, agora_group_id) FROM stdin;
\.


--
-- Data for Name: invite_code_usages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invite_code_usages (id, invite_code_id, user_id, used_at) FROM stdin;
1	1	660	2026-06-28 17:02:03.6507
\.


--
-- Data for Name: invite_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invite_codes (id, code, status, used_by_user_id, used_by_username, used_by_fullname, created_at, used_at, total_count, used_count, remark) FROM stdin;
1	qUXKnX	unused	\N	\N	\N	2026-06-28 17:01:58.65955	\N	100	1	\N
2	1E2F2C19	unused	\N	\N	\N	2026-07-02 12:57:28.302505	\N	1	0	\N
3	DC3E3376	unused	\N	\N	\N	2026-07-02 12:57:28.302505	\N	1	0	\N
4	287893F7	unused	\N	\N	\N	2026-07-02 12:57:37.647398	\N	1	0	\N
5	192DE97B	unused	\N	\N	\N	2026-07-02 12:57:37.647398	\N	1	0	\N
6	E4A28CB6	unused	\N	\N	\N	2026-07-02 13:00:02.128418	\N	1	0	\N
7	66C44454	unused	\N	\N	\N	2026-07-02 13:00:02.128418	\N	1	0	\N
8	A522D0F1	unused	\N	\N	\N	2026-07-02 13:01:19.419922	\N	1	0	\N
9	0ED32903	unused	\N	\N	\N	2026-07-02 13:01:19.419922	\N	1	0	\N
10	7BCC0A14	unused	\N	\N	\N	2026-07-02 13:01:19.419922	\N	1	0	\N
\.


--
-- Data for Name: scheduled_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scheduled_messages (id, sender_id, receiver_id, message_type, title, send_time, send_type, content, status, created_at, updated_at, send_date) FROM stdin;
\.


--
-- Data for Name: server_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.server_settings (id, key, value, description, updated_at) FROM stdin;
\.


--
-- Data for Name: synced_group_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.synced_group_messages (id, agora_msg_id, group_id, sender_id, sender_name, sender_nickname, sender_full_name, content, message_type, file_name, voice_duration, call_type, quoted_message_content, status, created_at, synced_at) FROM stdin;
\.


--
-- Data for Name: synced_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.synced_messages (id, agora_msg_id, sender_id, sender_name, receiver_id, receiver_name, content, message_type, file_name, voice_duration, call_type, quoted_message_content, status, is_read, created_at, synced_at) FROM stdin;
\.


--
-- Data for Name: user_relations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_relations (id, user_id, friend_id, created_at, approval_status, is_blocked, is_deleted, blocked_by_user_id, deleted_by_user_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, phone, email, avatar, created_at, updated_at, auth_code, full_name, gender, work_signature, status, landline, short_number, department, "position", region, invite_code, invited_by_code, voip_token, voip_token_updated_at, last_login_at, is_overseas, active_token, token_updated_at, remark) FROM stdin;
661	test999	$2a$10$M/NDnk0TlW8YiXB4KC.t3.2B3bLZEEL4QB1DUryA/cTvqQZyJ0HYu	\N	\N		2026-07-02 12:58:19.016311	2026-07-02 12:58:19.016311	\N	ceshi999	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
124	test31	$2a$10$Ab6B9CTJp7A1qh0jqTwMXOEn79/G/pUi2L83g9/waF.vaHU6f86/C	\N	\N		2025-11-27 06:32:25.759358	2026-07-05 04:15:12.59042	\N	测试31	\N	\N	offline	\N	\N	\N	\N	\N	TtOCO7	\N	\N	\N	2026-07-05 04:01:23.40815	0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxMjQsInVzZXJuYW1lIjoidGVzdDMxIiwiZXhwIjoxNzgzODI4ODgzLCJuYmYiOjE3ODMyMjQwODMsImlhdCI6MTc4MzIyNDA4M30.h4Vm7pYrmJxhCwEg0hS_MtaLfVwBF2KgiI45rYTv70c	2026-07-05 12:01:23.406065+08	\N
104	test03	$2a$10$kByMCMm.Y47JpqWpOV9NG.WE0fuSLy2b5focqkbqSdcnF0lW9zGe.	\N	\N		2025-11-24 17:36:14.534498	2026-06-28 07:20:56.311437	\N	测试03	\N	\N	offline	\N	\N	\N	\N	\N	666666	\N	\N	\N	2026-06-28 07:19:55.274528	0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxMDQsInVzZXJuYW1lIjoidGVzdDAzIiwiZXhwIjoxNzgzMjM1OTk1LCJuYmYiOjE3ODI2MzExOTUsImlhdCI6MTc4MjYzMTE5NX0.YipEvK4cZqfxFDTelgbZgr69yFf7igrmFsLWp3OpHps	2026-06-28 15:19:55.271995+08	\N
105	test04	$2a$10$Fm3Q5vPVgXwYZwVI4iqG7.QUSXtXQ2FxUlehsmypbh6NzvtP3dEiO	\N	\N		2025-11-24 22:21:53.621795	2026-06-28 17:02:52.800404	\N	测试04	\N	\N	online	\N	\N	\N	\N	\N	K3Ogct	\N	\N	\N	2026-06-28 08:46:56.526012	0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxMDUsInVzZXJuYW1lIjoidGVzdDA0IiwiZXhwIjoxNzgzMjQxMjE2LCJuYmYiOjE3ODI2MzY0MTYsImlhdCI6MTc4MjYzNjQxNn0.EUgJhvs46wslDttiosDwrqYTgwtHs37grU4cdb6fATk	2026-06-28 16:46:56.523843+08	\N
152	wxh1	$2a$10$zGp/1ngnW79Wvks7aBNFYOuK1GsoccGhmEKMeJkLU2jFlOrIG4P8S	\N	\N		2025-12-06 14:54:24.023958	2026-01-09 12:05:18.311506	\N	wxh	\N	\N	online	\N	\N	\N	\N	\N	ptrSum	666666	\N	\N	\N	0	\N	\N	\N
150	dj001	$2a$10$rklcLD426DsuPgExqz..WOfAqHjFq1ple02HF4un8jXKiNHYplllC	\N	\N		2025-12-06 10:32:12.897471	2026-01-09 12:05:18.311506	\N	大江	\N	不成功便成仁，	offline	\N	\N	\N	\N	\N	6zQD3d	666666	\N	\N	\N	0	\N	\N	\N
158	test922	$2a$10$.vc/gieNK3WJ1gbhkKum3exBNLs4v2HIO38Aiv1iOOoWLfp0fh72y	\N	\N		2025-12-19 09:52:27.699365	2026-01-09 12:05:18.311506	\N	ceshi922	\N	\N	offline	\N	\N	\N	\N	\N	eAH25u	666666	\N	\N	\N	0	\N	\N	\N
107	test06	$2a$10$.KpWdHmmFNCIj/pMEH5BwuxShNCcz6TjXiEUiO8Eja1g/X23elPCu	\N	\N		2025-11-25 11:58:13.736898	2026-01-09 12:05:18.311506	\N	测试06	\N	\N	offline	\N	\N	\N	\N	\N	Rri1WK	\N	\N	\N	\N	0	\N	\N	\N
154	sfq80801	$2a$10$3iEIP74SayUnQL3ZFqYA9ufHdjJLwUytWiwHWQajY1eElVJIPsug.	\N	\N		2025-12-13 09:42:50.879754	2026-01-09 12:05:18.311506	\N	夜风来袭	\N	\N	offline	\N	\N	\N	\N	\N	ce7fUb	666666	\N	\N	\N	0	\N	\N	\N
146	WZH6688	$2a$10$efSJUY2Mxms0K0A4Zgm6Z.og4kGSc/Nzgu4.e5R6hYmdq7m7H08Um	\N	\N		2025-12-06 10:25:31.680899	2026-01-09 12:05:18.311506	\N	王志豪	\N	\N	offline	\N	\N	\N	\N	\N	s0ygTk	666666	\N	\N	\N	0	\N	\N	\N
155	AA1122	$2a$10$6eA7cEPoAE1FYPW4XSee3OJHnViW8mlL5TCtIv6j2aWzrUp7vBqgK	\N	\N		2025-12-14 10:20:33.891178	2026-01-09 12:05:18.311506	\N	阿宇	\N	\N	offline	\N	\N	\N	\N	\N	l4xW3w	95hWRS	\N	\N	\N	0	\N	\N	\N
111	test20	$2a$10$.G9/nBcXlJcoNIM6m61Ohu5BRWvvX0zZsH5vr4og9zVJDLM46OwNG	\N	\N		2025-11-25 13:19:01.898295	2026-01-09 12:05:18.311506	\N	测试20	\N	\N	offline	\N	\N	\N	\N	\N	8QCI6H	\N	\N	\N	\N	0	\N	\N	\N
142	ces001	$2a$10$HuzBE8pUeKmC38beO1MhN.savf7qXXrD9ojebaNZrQlMhBgJPooDW	的广泛受到广泛的1111	<script>alter('1')</script>11111	https://chat-youdu-2.oss-cn-hongkong.aliyuncs.com/avatars/1764393312_JPEG_20251129_131511_2366789718876412309.jpg	2025-11-29 04:45:00.855735	2026-01-09 12:05:18.311506	\N	1ces001发顺丰到付公司的ces001发顺丰到付公司的ces001发顺丰到付公司的ces001发顺丰到付公司的ces001发顺丰到付公司的	male	1111<script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter('1')</script><script>alter(	offline	q11111	11111	<script>alter('1')</script>11111	<script>alter('1')</script>1111	<script>alter('1')</script>1111	xW9sEa	\N	\N	\N	\N	0	\N	\N	\N
143	ces002	$2a$10$LGf56v6mB2ZoldDA/naiuuAhG533Tfn6s3ZIKOTzoGHc8V/ML35Fu	13852425252	jaajapappaapappad@qq.com	https://chat-youdu-2.oss-cn-hongkong.aliyuncs.com/avatars/1764395761_屏幕截图 2025-08-12 125412.png	2025-11-29 05:06:33.640026	2026-01-09 12:05:18.311506	\N	可可粉咳咳咳咳咳咳咳咳姐咳xcyufguguuggu咳咳咳咳咳咳	male	vcxvxcv	online			啊撒撒撒的热热热特特	并不是说看快手咳咳咳咳上课上课可	老婆老婆热可可热热可热了fyfyytdyxxyffcycycyfuufuffuuggu	TywbzT	\N	\N	\N	\N	0	\N	\N	\N
117	qiufeng1	$2a$10$KdRwqdss348crc51HldB5uIn1NdMtHfFl4L712T6zeeyKtcFQctX.			https://chat-youdu-2.oss-cn-hongkong.aliyuncs.com/avatars/1764167893_GH_20logo151639.png.png	2025-11-26 14:21:13.644025	2026-01-09 12:05:18.311506	\N	秋风2	male	\N	offline						Hsyde3	\N	\N	\N	\N	0	\N	\N	\N
126	test900	$2a$10$E.gJG.I6vsVU3GCbnk4jeuNMdgpeCJrLfU2qdbGWKmPxi1LBN6/Di	\N	\N		2025-11-28 00:00:57.496309	2026-06-28 20:40:45.780082	\N	123	\N	\N	offline	\N	\N	\N	\N	\N	x0dLTN	\N	\N	\N	2026-06-28 12:32:15.313263	0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxMjYsInVzZXJuYW1lIjoidGVzdDkwMCIsImV4cCI6MTc4MzI1NDczNSwibmJmIjoxNzgyNjQ5OTM1LCJpYXQiOjE3ODI2NDk5MzV9.dv_AnHoJiq70vbmuD2LP7zvC-Y3A3Jr0RHjH9zWpv9s	2026-06-28 12:32:15.30379+08	\N
662	test998	$2a$10$5Mt/HkM58Py5.DzGe/qTouEXfrtUPVKyFAjn0.FJCwlSEeQBGmIku	\N	\N		2026-07-02 12:58:45.331904	2026-07-02 12:58:45.331904	\N	ceshi998	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
148	adi1234	$2a$10$8SxDCLH6f8qqRbxp0LeoOu.Hzjhyhu2NlgR0h6mtruFZZTPlBY6KG			https://chat-youdu-2.oss-cn-hongkong.aliyuncs.com/images/user/148/1765678342601134207_Screenshot_2025-12-09-21-03-08-753_com.miui.gallery-edit.jpg	2025-12-06 10:26:58.824751	2026-01-09 12:05:18.311506	\N	阿迪	male	\N	offline	\N	\N				95hWRS	666666	\N	\N	\N	0	\N	\N	\N
147	sanpao888	$2a$10$e2vs0NDFWeXVfYHyg8Eo7.WxAg2q75JZn4bdTrmf9ZbcgE5kwfP7G	15816818817	pao@outlook.com	https://chat-youdu-2.oss-cn-hongkong.aliyuncs.com/avatars/1765002326_JPEG_20251206_142525_6675084135310091532.jpg	2025-12-06 10:26:26.269175	2026-01-09 12:05:18.311506	\N	风生水起	male	\N	offline	\N	\N	业务部	你猜	陕西	UlkXS4	666666	\N	\N	\N	0	\N	\N	\N
149	sfq80810	$2a$10$YDfOr/LZBpnvz8QaArBW4OAl4eDbOMt68vGlRFNo8lvB3ziujfljW	13333333333	10000@qq.com	https://chat-youdu-2.oss-cn-hongkong.aliyuncs.com/avatars/1765002345_JPEG_20251206_142548_1632189368049207096.jpg	2025-12-06 10:27:18.52056	2026-01-09 12:05:18.311506	\N	苏	male	\N	offline	\N	\N	1	1	1	md3ceI	666666	\N	\N	\N	0	\N	\N	\N
153	wxh2	$2a$10$/uBnKOMh40urJ6m.QYvfqenCDVfxgcKYR9XHxM5wjjME6Ufw6W5ym	\N	\N		2025-12-06 14:55:07.139953	2026-01-09 12:05:18.311506	\N	wxhh	\N	\N	offline	\N	\N	\N	\N	\N	NvNdjl	666666	\N	\N	\N	0	\N	\N	\N
157	ces006	$2a$10$29XPy0YWoJ8PvBIueDofAuacp39c/i2EjRUtg1GL1YY3xvGEd6wTm	\N	\N		2025-12-14 15:38:25.148958	2026-01-09 12:05:18.311506	\N	显示第 1 到第 1 条记录，总共 1 条记录显示第 1 到第 1 条记录，总共 1 条记录显示第 1 到第 1 条记录，总共 1 条记录	\N	\N	offline	\N	\N	\N	\N	\N	kbwmxg	666666	\N	\N	\N	0	\N	\N	\N
156	ces004	$2a$10$9mxqETTEomRtw0092M80lePq7sGkGimxAffY3.DX97oL9wW4GJHZ2	\N	\N		2025-12-14 15:37:28.927357	2026-01-09 12:05:18.311506	\N	所有为了保证系统统一性，后台和客户端涉及地址地方都使用的该表，但新安装是不存在，地区表数据又庞大，所有我们也没有内置	\N	\N	offline	\N	\N	\N	\N	\N	DsgsWx	666666	\N	\N	\N	0	\N	\N	\N
151	wxs6688	$2a$10$/5oH3YZWPgaqGyWXgnUfUuiiYDnqYnuL7qgN5i/KjGZqW/vrYoOmG			https://chat-youdu-2.oss-cn-hongkong.aliyuncs.com/avatars/1765004029_JPEG_20251206_145348_7283309526769554210.jpg	2025-12-06 10:36:34.44	2026-01-09 12:05:18.311506	\N	王先生	male	\N	offline	\N	\N				0pQZqw	666666	\N	\N	\N	0	\N	\N	\N
145	qiufeng11	$2a$10$..hMi8/7Lal/Rb1EV0VZR.zBBYxlrW9W6a0cFBG3ErdYM5AI8JH3y	\N	\N		2025-12-03 21:35:31.86807	2026-01-09 12:05:18.311506	\N	秋风	\N	\N	offline	\N	\N	\N	\N	\N	jXMUZ7	666666	\N	\N	\N	0	\N	\N	\N
159	test25	$2a$10$W77y582rSkWCBakCiSOimOAtTLNRZ/k2UZs5TctnA34IsdxU4okDe	\N	\N		2025-12-19 10:45:23.040448	2026-01-09 12:05:18.311506	\N	ceshi25	\N	\N	offline	\N	\N	\N	\N	\N	DS9ryR	666666	\N	\N	\N	0	\N	\N	\N
123	test100	$2a$10$L8n1JOJgagu85FNY2tZAPOI2vuaJMfoovP/QXGCkTv.yWVunqElc2	\N	\N		2025-11-27 01:30:16.374876	2026-01-09 12:05:18.311506	\N	测试100	\N	\N	offline	\N	\N	\N	\N	\N	xBPCUb	\N	\N	\N	\N	0	\N	\N	\N
134	test909	$2a$10$9EWNU7fFsOtA8TEM8KIxpeOhk2Yz3mlExD5cqsIbIBjy2qHfFb8b2	\N	\N		2025-11-28 06:46:20.846748	2026-01-09 12:05:18.311506	\N	测试909	\N	\N	online	\N	\N	\N	\N	\N	nfMYHK	\N	\N	\N	\N	0	\N	\N	\N
113	test22	$2a$10$ATfNIdUDVtWLhSeF6dMvL.m3EQEUFaFDgVb/GK7yNlQFY8.b4XORa			https://chat-youdu-2.oss-cn-hongkong.aliyuncs.com/avatars/1764129559_ic_launcher.png	2025-11-25 17:55:13.217482	2026-06-28 20:12:12.497832	\N	测试22	male	errt	offline						hIAuk3	\N	\N	\N	2026-06-28 12:03:30.338116	0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxMTMsInVzZXJuYW1lIjoidGVzdDIyIiwiZXhwIjoxNzgzMjUzMDEwLCJuYmYiOjE3ODI2NDgyMTAsImlhdCI6MTc4MjY0ODIxMH0.z_kqlKWvWlMnTkGUL8Kcz31vqwvB0_zprABHmPAFit4	2026-06-28 12:03:30.333629+08	\N
141	qiufeng2	$2a$10$tC2ydOFg1THLe1OC84qVJOpbrETZznCRqkTXiBi855XAIojZ1KXo.				2025-11-28 08:04:19.618639	2026-01-09 12:05:18.311506	\N	秋风2	male	\N	offline						ggzrDO	\N	\N	\N	\N	0	\N	\N	\N
135	test910	$2a$10$4YfYLTGloHAW3FGml5JB8u1mYhAwJnWRE4GLsY5rOSYaEvcRe5vX2	\N	\N		2025-11-28 07:04:57.615503	2026-01-09 12:05:18.311506	\N	昵称910	\N	\N	online	\N	\N	\N	\N	\N	OqSnXZ	\N	\N	\N	\N	0	\N	\N	\N
120	youdu2	$2a$10$VYeIyRBGcPJoaCMt/9UyN.et5f6vEjMMBcElt50IzjxRtF7Ujg4Ea	\N	\N		2025-11-26 19:35:18.663729	2026-01-09 12:05:18.311506	\N	有度2	\N	\N	offline	\N	\N	\N	\N	\N	OJvcX3	\N	\N	\N	\N	0	\N	\N	\N
129	test904	$2a$10$aUwhqiUDk7P/w3DsDWKbF.933HGQ2lIsZKj8DgcaihQAE4hrBnmJi	\N	\N		2025-11-28 06:12:29.512534	2026-01-09 12:05:18.311506	\N	测试904	\N	\N	offline	\N	\N	\N	\N	\N	HQrHNw	\N	\N	\N	\N	0	\N	\N	\N
125	test35	$2a$10$S96svAO/1hFW98e2rqA6Sukb54my2PbvDE3.8n/GNiYI0g1VEWxty	\N	\N		2025-11-27 11:47:10.959457	2026-01-09 12:05:18.311506	\N	测试35	\N	\N	offline	\N	\N	\N	\N	\N	IU28dJ	\N	\N	\N	\N	0	\N	\N	\N
121	youdu3	$2a$10$QVve1LP3QSSKwj1h6CIas.yoHB3P/9oKr.yJh/yaM8gRAkCuw5mdG	\N	\N		2025-11-26 19:39:03.740618	2026-01-09 12:05:18.311506	\N	有度3	\N	\N	offline	\N	\N	\N	\N	\N	nqzSqr	\N	\N	\N	\N	0	\N	\N	\N
132	test907	$2a$10$fqZ2Kgfyg2w6WRzLHo6L2e4ovGd2zUJmQAVKbIGcHMtzOYh/VTFD2	\N	\N		2025-11-28 06:26:40.752577	2026-01-09 12:05:18.311506	\N	测试907	\N	\N	offline	\N	\N	\N	\N	\N	wn6jF0	\N	\N	\N	\N	0	\N	\N	\N
128	test902	$2a$10$cy4M4hutVkww8IOPOHsmyeIq8z87Rb0ngMq2rULB3z5k5yPQdw0ci	\N	\N		2025-11-28 06:10:06.367996	2026-01-09 12:05:18.311506	\N	测试902	\N	\N	offline	\N	\N	\N	\N	\N	8wps5g	\N	\N	\N	\N	0	\N	\N	\N
122	test99	$2a$10$QJCu7Sn7S1KkJaKtoyLQIOoIc5fQC.a8K6wG3lSfF6KqnAEE7PRHq	\N	\N		2025-11-27 01:29:20.575165	2026-01-09 12:05:18.311506	\N	测试99	\N	\N	offline	\N	\N	\N	\N	\N	FbglOo	\N	\N	\N	\N	0	\N	\N	\N
133	test908	$2a$10$MLLJza/ucdYYY66XtYNM9u7V5If5778oa.1cQGeP664ml5C9gy3.S	\N	\N		2025-11-28 06:42:23.148388	2026-01-09 12:05:18.311506	\N	测试908	\N	\N	offline	\N	\N	\N	\N	\N	zH967n	\N	\N	\N	\N	0	\N	\N	\N
131	test906	$2a$10$iHElm5HaJ1kWnl0YyK1/AuH/PssqxMxh/bRrDGyVgbnUdN.qwcUdi	\N	\N		2025-11-28 06:24:39.616135	2026-01-09 12:05:18.311506	\N	测试906	\N	\N	offline	\N	\N	\N	\N	\N	CH3tDT	\N	\N	\N	\N	0	\N	\N	\N
138	test913	$2a$10$XW/kzSD4ZAsZchiYtc7r2exoCf7bkmaerwe3h1bnWkzbnk8uz.n2O	\N	\N		2025-11-28 07:13:17.380187	2026-01-09 12:05:18.311506	\N	测试913	\N	\N	offline	\N	\N	\N	\N	\N	G6J4RD	\N	\N	\N	\N	0	\N	\N	\N
137	test912	$2a$10$5lx/VIIdv4.e9Vbxd6WnjuL7NbYFYxJJpnIdEV6YSaRKnE7sNdC6a	\N	\N		2025-11-28 07:10:04.032567	2026-01-09 12:05:18.311506	\N	测试912	\N	\N	offline	\N	\N	\N	\N	\N	1wHDYc	\N	\N	\N	\N	0	\N	\N	\N
139	test914	$2a$10$aao7IzRD7XOAZe1Q2ndfFesP/ombx0m2R3wfaO8TSZwDsUf9vIzIO	\N	\N		2025-11-28 07:15:30.723365	2026-01-09 12:05:18.311506	\N	测试914	\N	\N	online	\N	\N	\N	\N	\N	qCo4If	\N	\N	\N	\N	0	\N	\N	\N
140	test831	$2a$10$03vQPQM0/o3VaWKLbpaAleb.r36W3oI7Le01vDcTF58uGcN3/j3XW	\N	\N		2025-11-28 07:59:03.687056	2026-01-09 12:05:18.311506	\N	测试831	\N	\N	offline	\N	\N	\N	\N	\N	jysqLT	\N	\N	\N	\N	0	\N	\N	\N
130	test905	$2a$10$7X9uJNSwYKlIEggg0GEUauY209wkb6IvTSTguuIF9lzaUhjLEagrG	\N	\N		2025-11-28 06:22:59.560673	2026-01-09 12:05:18.311506	\N	测试905	\N	\N	offline	\N	\N	\N	\N	\N	gQGSLQ	\N	\N	\N	\N	0	\N	\N	\N
116	qiufeng	$2a$10$WGT2RL6k9.TkDEifdDLmten/OysbtHphdRQefDWdawES4B.8UiiVC			https://chat-youdu-2.oss-cn-hongkong.aliyuncs.com/avatars/1764167864_JPEG_20251126_223743_2801915060574922910.jpg	2025-11-26 14:19:55.691941	2026-01-09 12:05:18.311506	\N	秋风1	male	\N	offline	\N	\N				fPUgZ9	\N	\N	\N	\N	0	\N	\N	\N
118	youdu1	$2a$10$GJTfWb9..2xL57zjpIAJUOghtjgNNiK4MB/dKDUkE6G64G3WXs2My	\N	\N		2025-11-26 14:30:37.444255	2026-01-09 12:05:18.311506	\N	有度	\N	\N	offline	\N	\N	\N	\N	\N	bHpjXp	\N	\N	\N	\N	0	\N	\N	\N
136	test911	$2a$10$U9SX997s7aMYLEZQ9PYkLOHpEJmJ2CJfq5m6cpz9S/iXAAanyE2sy	\N	\N		2025-11-28 07:08:40.748777	2026-01-09 12:05:18.311506	\N	测试911	\N	\N	offline	\N	\N	\N	\N	\N	n9gT8U	\N	\N	\N	\N	0	\N	\N	\N
112	test21	$2a$10$Eaj1zQhgPJEqdQWaLa8P6.NIUf4Drc38eChifjExQSKJsWdDvlYxa	\N	\N		2025-11-25 13:19:49.620411	2026-01-09 12:05:18.311506	\N	测试21	\N	\N	offline	\N	\N	\N	\N	\N	9wjxQp	\N	\N	\N	\N	0	\N	\N	\N
114	test23	$2a$10$GpkCQkQ4ra.Pv73rwAiYTuB/sz6Q5b2Vl34GBseFrAj1/jnQg2r4u			https://chat-youdu-2.oss-cn-hongkong.aliyuncs.com/avatars/1764129472_JPEG_20251126_115752_2461943808010734271.jpg	2025-11-25 17:56:40.890524	2026-01-09 12:05:18.311506	\N	测试23	male	\N	offline	\N	\N				zHxx7p	\N	\N	\N	\N	0	\N	\N	\N
108	test07	$2a$10$yJCg/1THxS0reCHZuSmw0u4I15gQbBSrf50uTxeukvUWkUE2N4KIK	\N	\N		2025-11-25 12:33:05.712664	2026-01-09 12:05:18.311506	\N	测试07	\N	\N	offline	\N	\N	\N	\N	\N	pl3aH0	\N	\N	\N	\N	0	\N	\N	\N
109	test08	$2a$10$F2bLFd0ymS2Z49VUu4ORnuPhwYYD6F557ux1Armlug.RgE0D5g/l6	\N	\N		2025-11-25 12:47:11.273864	2026-01-09 12:05:18.311506	\N	测试08	\N	\N	online	\N	\N	\N	\N	\N	tHQ0bH	\N	\N	\N	\N	0	\N	\N	\N
205	test1046	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1046	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
206	test1047	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1047	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
207	test1048	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1048	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
208	test1049	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1049	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
209	test1050	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1050	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
210	test1051	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1051	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
211	test1052	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1052	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
212	test1053	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1053	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
213	test1054	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1054	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
214	test1055	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1055	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
215	test1056	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1056	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
216	test1057	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1057	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
110	test09	$2a$10$1rrVDyQSoXiISY1ElZOQRO5dRCPPzFDiwtwp6ra0xI2UYzrd0zHMK	\N	\N		2025-11-25 13:02:50.353647	2026-06-28 16:28:10.045725	\N	测试09	\N	\N	offline	\N	\N	\N	\N	\N	rXVRb2	\N	\N	\N	2026-06-28 08:27:49.619971	0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxMTAsInVzZXJuYW1lIjoidGVzdDA5IiwiZXhwIjoxNzgzMjQwMDY5LCJuYmYiOjE3ODI2MzUyNjksImlhdCI6MTc4MjYzNTI2OX0.SMTP0raq2T638p0FGGcc9ibCFn2_4KOeF8nxDd0_RvM	2026-06-28 08:27:49.61788+08	\N
160	test1001	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1001	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
161	test1002	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1002	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
162	test1003	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1003	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
163	test1004	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1004	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
164	test1005	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1005	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
165	test1006	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1006	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
166	test1007	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1007	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
167	test1008	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1008	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
168	test1009	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1009	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
169	test1010	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1010	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
144	ces003	$2a$10$nqEGOj6dyTAXFz6MQ8Utxuh/yonnlKsMhoskuhEHcwEAnLqboCBdG	13598797897	11@qq.com	https://chat-youdu-2.oss-cn-hongkong.aliyuncs.com/avatars/1764489309_图片合成.png	2025-11-29 06:56:36.541428	2026-01-09 12:05:18.311506	\N	cesfffff	female	fgdfhgdfgbb	online			11	11	11	mWHIp8	\N	\N	\N	\N	0	\N	\N	\N
170	test1011	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1011	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
171	test1012	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1012	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
127	test901	$2a$10$HcS9fO18ZOv0JF5PY6wY1u/Dyjp.PwywGbveid6JXWrAb58EVlhP6				2025-11-28 00:02:04.303367	2026-01-09 12:05:18.311506	\N	测试901	male	\N	offline						ocfZbc	\N	\N	\N	\N	0	\N	\N	\N
115	test30	$2a$10$5volaozylAbd5Z5N7mllWeMdgGy1EdmUtrJsgq2/UmUMhtIWxv9vi	\N	\N		2025-11-26 08:51:28.094057	2026-01-09 12:05:18.311506	\N	测试30	\N	\N	offline	\N	\N	\N	\N	\N	G5zSPm	\N	\N	\N	\N	0	\N	\N	\N
172	test1013	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1013	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
173	test1014	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1014	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
174	test1015	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1015	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
175	test1016	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1016	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
176	test1017	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1017	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
177	test1018	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1018	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
178	test1019	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1019	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
179	test1020	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1020	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
180	test1021	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1021	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
181	test1022	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1022	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
182	test1023	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1023	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
183	test1024	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1024	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
184	test1025	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1025	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
185	test1026	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1026	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
186	test1027	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1027	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
187	test1028	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1028	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
188	test1029	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1029	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
189	test1030	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1030	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
190	test1031	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1031	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
191	test1032	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1032	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
192	test1033	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1033	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
193	test1034	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1034	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
194	test1035	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1035	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
195	test1036	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1036	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
196	test1037	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1037	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
197	test1038	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1038	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
198	test1039	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1039	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
199	test1040	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1040	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
200	test1041	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1041	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
201	test1042	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1042	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
202	test1043	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1043	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
203	test1044	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1044	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
204	test1045	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.434076	2026-01-23 21:18:25.434076	\N	测试用户1045	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
217	test1058	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1058	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
218	test1059	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1059	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
219	test1060	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1060	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
220	test1061	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1061	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
221	test1062	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1062	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
222	test1063	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1063	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
223	test1064	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1064	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
224	test1065	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1065	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
225	test1066	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1066	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
226	test1067	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1067	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
227	test1068	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1068	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
228	test1069	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1069	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
229	test1070	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1070	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
230	test1071	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1071	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
231	test1072	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1072	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
232	test1073	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1073	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
233	test1074	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1074	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
234	test1075	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1075	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
235	test1076	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1076	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
236	test1077	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1077	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
237	test1078	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1078	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
238	test1079	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1079	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
239	test1080	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1080	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
240	test1081	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1081	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
241	test1082	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1082	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
242	test1083	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1083	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
243	test1084	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1084	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
244	test1085	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1085	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
245	test1086	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1086	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
246	test1087	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1087	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
247	test1088	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1088	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
248	test1089	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1089	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
249	test1090	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1090	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
250	test1091	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1091	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
251	test1092	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1092	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
252	test1093	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1093	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
253	test1094	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1094	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
254	test1095	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1095	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
255	test1096	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1096	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
256	test1097	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1097	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
257	test1098	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1098	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
258	test1099	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1099	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
259	test1100	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.443904	2026-01-23 21:18:25.443904	\N	测试用户1100	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
260	test1101	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1101	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
261	test1102	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1102	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
262	test1103	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1103	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
263	test1104	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1104	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
264	test1105	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1105	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
265	test1106	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1106	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
266	test1107	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1107	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
267	test1108	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1108	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
268	test1109	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1109	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
269	test1110	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1110	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
270	test1111	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1111	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
271	test1112	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1112	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
272	test1113	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1113	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
273	test1114	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1114	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
274	test1115	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1115	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
275	test1116	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1116	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
276	test1117	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1117	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
277	test1118	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1118	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
278	test1119	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1119	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
279	test1120	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1120	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
280	test1121	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1121	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
281	test1122	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1122	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
282	test1123	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1123	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
283	test1124	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1124	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
284	test1125	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1125	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
285	test1126	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1126	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
286	test1127	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1127	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
287	test1128	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1128	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
288	test1129	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1129	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
289	test1130	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1130	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
290	test1131	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1131	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
291	test1132	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1132	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
292	test1133	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1133	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
293	test1134	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1134	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
294	test1135	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1135	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
295	test1136	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1136	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
296	test1137	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1137	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
297	test1138	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1138	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
298	test1139	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1139	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
299	test1140	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1140	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
300	test1141	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1141	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
301	test1142	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1142	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
302	test1143	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1143	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
303	test1144	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1144	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
304	test1145	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1145	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
305	test1146	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1146	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
306	test1147	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1147	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
307	test1148	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1148	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
308	test1149	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1149	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
309	test1150	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.447625	2026-01-23 21:18:25.447625	\N	测试用户1150	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
310	test1151	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1151	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
311	test1152	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1152	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
312	test1153	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1153	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
313	test1154	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1154	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
314	test1155	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1155	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
315	test1156	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1156	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
316	test1157	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1157	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
317	test1158	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1158	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
318	test1159	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1159	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
319	test1160	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1160	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
320	test1161	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1161	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
321	test1162	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1162	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
322	test1163	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1163	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
323	test1164	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1164	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
324	test1165	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1165	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
325	test1166	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1166	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
326	test1167	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1167	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
327	test1168	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1168	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
328	test1169	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1169	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
329	test1170	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1170	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
330	test1171	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1171	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
331	test1172	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1172	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
332	test1173	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1173	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
333	test1174	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1174	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
334	test1175	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1175	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
335	test1176	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1176	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
336	test1177	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1177	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
337	test1178	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1178	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
338	test1179	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1179	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
339	test1180	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1180	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
340	test1181	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1181	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
341	test1182	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1182	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
342	test1183	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1183	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
343	test1184	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1184	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
344	test1185	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1185	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
345	test1186	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1186	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
346	test1187	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1187	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
347	test1188	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1188	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
348	test1189	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1189	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
349	test1190	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1190	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
350	test1191	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1191	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
351	test1192	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1192	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
352	test1193	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1193	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
353	test1194	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1194	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
354	test1195	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1195	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
355	test1196	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1196	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
356	test1197	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1197	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
357	test1198	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1198	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
358	test1199	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1199	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
359	test1200	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.451235	2026-01-23 21:18:25.451235	\N	测试用户1200	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
360	test1201	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1201	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
361	test1202	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1202	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
362	test1203	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1203	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
363	test1204	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1204	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
364	test1205	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1205	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
365	test1206	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1206	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
366	test1207	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1207	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
367	test1208	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1208	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
368	test1209	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1209	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
369	test1210	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1210	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
370	test1211	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1211	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
371	test1212	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1212	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
372	test1213	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1213	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
373	test1214	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1214	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
374	test1215	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1215	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
375	test1216	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1216	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
376	test1217	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1217	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
377	test1218	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1218	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
378	test1219	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1219	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
379	test1220	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1220	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
380	test1221	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1221	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
381	test1222	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1222	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
382	test1223	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1223	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
383	test1224	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1224	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
384	test1225	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1225	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
385	test1226	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1226	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
386	test1227	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1227	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
387	test1228	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1228	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
388	test1229	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1229	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
389	test1230	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1230	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
390	test1231	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1231	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
391	test1232	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1232	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
392	test1233	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1233	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
393	test1234	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1234	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
394	test1235	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1235	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
395	test1236	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1236	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
396	test1237	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1237	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
397	test1238	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1238	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
398	test1239	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1239	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
399	test1240	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1240	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
400	test1241	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1241	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
401	test1242	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1242	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
402	test1243	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1243	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
403	test1244	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1244	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
404	test1245	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1245	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
405	test1246	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1246	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
406	test1247	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1247	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
407	test1248	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1248	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
408	test1249	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1249	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
409	test1250	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.454649	2026-01-23 21:18:25.454649	\N	测试用户1250	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
410	test1251	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1251	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
411	test1252	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1252	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
412	test1253	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1253	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
413	test1254	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1254	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
414	test1255	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1255	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
415	test1256	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1256	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
416	test1257	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1257	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
417	test1258	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1258	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
418	test1259	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1259	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
419	test1260	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1260	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
420	test1261	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1261	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
421	test1262	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1262	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
422	test1263	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1263	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
423	test1264	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1264	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
424	test1265	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1265	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
425	test1266	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1266	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
426	test1267	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1267	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
427	test1268	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1268	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
428	test1269	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1269	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
429	test1270	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1270	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
430	test1271	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1271	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
431	test1272	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1272	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
432	test1273	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1273	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
433	test1274	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1274	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
434	test1275	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1275	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
435	test1276	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1276	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
436	test1277	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1277	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
437	test1278	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1278	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
438	test1279	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1279	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
439	test1280	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1280	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
440	test1281	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1281	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
441	test1282	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1282	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
442	test1283	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1283	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
443	test1284	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1284	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
444	test1285	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1285	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
445	test1286	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1286	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
446	test1287	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1287	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
447	test1288	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1288	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
448	test1289	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1289	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
449	test1290	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1290	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
450	test1291	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1291	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
451	test1292	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1292	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
452	test1293	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1293	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
453	test1294	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1294	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
454	test1295	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1295	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
455	test1296	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1296	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
456	test1297	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1297	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
457	test1298	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1298	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
458	test1299	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1299	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
459	test1300	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.459271	2026-01-23 21:18:25.459271	\N	测试用户1300	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
460	test1301	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1301	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
461	test1302	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1302	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
462	test1303	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1303	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
463	test1304	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1304	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
464	test1305	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1305	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
465	test1306	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1306	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
466	test1307	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1307	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
467	test1308	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1308	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
468	test1309	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1309	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
469	test1310	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1310	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
470	test1311	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1311	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
471	test1312	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1312	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
472	test1313	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1313	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
473	test1314	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1314	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
474	test1315	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1315	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
475	test1316	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1316	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
476	test1317	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1317	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
477	test1318	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1318	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
478	test1319	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1319	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
479	test1320	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1320	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
480	test1321	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1321	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
481	test1322	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1322	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
482	test1323	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1323	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
483	test1324	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1324	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
484	test1325	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1325	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
485	test1326	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1326	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
486	test1327	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1327	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
487	test1328	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1328	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
488	test1329	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1329	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
489	test1330	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1330	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
490	test1331	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1331	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
491	test1332	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1332	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
492	test1333	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1333	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
493	test1334	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1334	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
494	test1335	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1335	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
495	test1336	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1336	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
496	test1337	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1337	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
497	test1338	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1338	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
498	test1339	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1339	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
499	test1340	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1340	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
500	test1341	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1341	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
501	test1342	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1342	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
502	test1343	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1343	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
503	test1344	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1344	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
504	test1345	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1345	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
505	test1346	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1346	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
506	test1347	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1347	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
507	test1348	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1348	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
508	test1349	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1349	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
509	test1350	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.462991	2026-01-23 21:18:25.462991	\N	测试用户1350	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
510	test1351	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1351	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
511	test1352	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1352	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
512	test1353	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1353	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
513	test1354	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1354	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
514	test1355	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1355	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
515	test1356	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1356	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
516	test1357	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1357	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
517	test1358	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1358	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
518	test1359	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1359	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
519	test1360	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1360	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
520	test1361	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1361	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
521	test1362	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1362	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
522	test1363	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1363	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
523	test1364	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1364	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
524	test1365	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1365	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
525	test1366	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1366	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
526	test1367	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1367	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
527	test1368	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1368	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
528	test1369	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1369	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
529	test1370	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1370	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
530	test1371	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1371	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
531	test1372	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1372	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
532	test1373	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1373	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
533	test1374	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1374	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
534	test1375	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1375	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
535	test1376	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1376	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
536	test1377	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1377	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
537	test1378	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1378	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
538	test1379	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1379	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
539	test1380	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1380	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
540	test1381	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1381	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
541	test1382	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1382	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
542	test1383	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1383	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
543	test1384	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1384	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
544	test1385	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1385	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
545	test1386	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1386	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
546	test1387	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1387	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
547	test1388	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1388	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
548	test1389	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1389	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
549	test1390	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1390	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
550	test1391	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1391	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
551	test1392	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1392	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
552	test1393	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1393	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
553	test1394	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1394	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
554	test1395	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1395	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
555	test1396	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1396	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
556	test1397	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1397	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
557	test1398	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1398	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
558	test1399	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1399	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
559	test1400	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.468556	2026-01-23 21:18:25.468556	\N	测试用户1400	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
560	test1401	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1401	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
561	test1402	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1402	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
562	test1403	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1403	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
563	test1404	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1404	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
564	test1405	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1405	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
565	test1406	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1406	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
566	test1407	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1407	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
567	test1408	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1408	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
568	test1409	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1409	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
569	test1410	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1410	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
570	test1411	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1411	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
571	test1412	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1412	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
572	test1413	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1413	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
573	test1414	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1414	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
574	test1415	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1415	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
575	test1416	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1416	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
576	test1417	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1417	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
577	test1418	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1418	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
578	test1419	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1419	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
579	test1420	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1420	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
580	test1421	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1421	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
581	test1422	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1422	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
582	test1423	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1423	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
583	test1424	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1424	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
584	test1425	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1425	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
585	test1426	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1426	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
586	test1427	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1427	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
587	test1428	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1428	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
588	test1429	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1429	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
589	test1430	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1430	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
590	test1431	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1431	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
591	test1432	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1432	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
592	test1433	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1433	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
593	test1434	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1434	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
594	test1435	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1435	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
595	test1436	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1436	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
596	test1437	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1437	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
597	test1438	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1438	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
598	test1439	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1439	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
599	test1440	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1440	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
600	test1441	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1441	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
601	test1442	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1442	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
602	test1443	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1443	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
603	test1444	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1444	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
604	test1445	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1445	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
605	test1446	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1446	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
606	test1447	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1447	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
607	test1448	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1448	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
608	test1449	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1449	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
609	test1450	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.471982	2026-01-23 21:18:25.471982	\N	测试用户1450	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
610	test1451	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1451	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
611	test1452	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1452	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
612	test1453	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1453	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
613	test1454	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1454	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
614	test1455	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1455	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
615	test1456	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1456	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
616	test1457	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1457	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
617	test1458	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1458	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
618	test1459	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1459	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
619	test1460	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1460	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
620	test1461	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1461	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
621	test1462	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1462	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
622	test1463	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1463	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
623	test1464	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1464	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
624	test1465	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1465	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
625	test1466	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1466	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
626	test1467	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1467	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
627	test1468	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1468	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
628	test1469	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1469	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
629	test1470	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1470	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
630	test1471	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1471	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
631	test1472	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1472	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
632	test1473	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1473	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
633	test1474	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1474	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
634	test1475	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1475	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
635	test1476	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1476	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
636	test1477	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1477	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
637	test1478	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1478	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
638	test1479	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1479	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
639	test1480	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1480	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
640	test1481	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1481	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
641	test1482	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1482	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
642	test1483	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1483	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
643	test1484	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1484	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
644	test1485	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1485	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
645	test1486	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1486	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
646	test1487	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1487	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
647	test1488	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1488	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
648	test1489	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1489	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
649	test1490	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1490	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
650	test1491	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1491	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
651	test1492	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1492	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
652	test1493	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1493	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
653	test1494	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1494	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
654	test1495	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1495	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
655	test1496	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1496	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
656	test1497	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1497	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
657	test1498	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1498	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
658	test1499	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1499	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
659	test1500	$2a$10$gJmPL4waxAmKoFaB5nNWn.RKa548VCiIapAXFfp0tPFqcEogI1Oqi	\N	\N		2026-01-23 21:18:25.476404	2026-01-23 21:18:25.476404	\N	测试用户1500	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N
103	test02	$2a$10$PrenWrXII9B6hC6nqFy9vuOytj6uwOMQr1wmSHG3buVhIKsJ7x8me			https://chat-youdu-2.oss-cn-hongkong.aliyuncs.com/avatars/1764129327_JPEG_20251126_115527_5144140681260080541.jpg	2025-11-24 15:17:23.407595	2026-03-17 00:49:15.172475	\N	测试2	male	\N	offline	\N	\N	yuhhg	hjvv		35YpXs	\N	805667c612b052cdfdbd278e7281afe88e190063db42b5d7d9cb7a20dd82708fd780d3ec4f2e3c1a964a3d55fc877c2a118770d79fcba0a55c6e45b5446ebdb6d3a5d89087e4d64f1abe777bb23a8ce3	2025-12-29 21:52:13.797704	2026-03-16 15:48:40.359673	0	\N	\N	\N
119	test10	$2a$10$7aWNurJ0HDU2FidMMXuH/Om3qtVMkedfiJsATq2ZSBUyvgpB4AMqS	\N	\N		2025-11-26 16:47:07.199907	2026-06-28 08:26:08.36034	\N	侧式0	\N	\N	offline	\N	\N	\N	\N	\N	0oBF4P	\N	\N	\N	2026-06-28 08:25:59.160326	0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxMTksInVzZXJuYW1lIjoidGVzdDEwIiwiZXhwIjoxNzgzMjM5OTU5LCJuYmYiOjE3ODI2MzUxNTksImlhdCI6MTc4MjYzNTE1OX0.dbRd5ffvJr-VuKzH9yNB2YyPsUOpToTd1l4L9Jm4Kes	2026-06-28 08:25:59.157156+08	\N
660	test32	$2a$10$vEZ9lqpQmCsZTJKGD9.0OOOqJcw0k8aEg02S1tQYhZKmnP73bQt1u	\N	\N		2026-06-28 09:02:03.646618	2026-06-28 17:12:45.201634	\N	ceshi32	\N	\N	offline	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-28 09:11:44.304139	0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjo2NjAsInVzZXJuYW1lIjoidGVzdDMyIiwiZXhwIjoxNzgzMjQyNzA0LCJuYmYiOjE3ODI2Mzc5MDQsImlhdCI6MTc4MjYzNzkwNH0.stR62PnF8R_Wk8qgZ89eyzomdr-8hAhwKdfjCXrkl94	2026-06-28 17:11:44.301682+08	\N
102	test01	$2a$10$y.M5Avb0FHVgydjPs.8jL.rWFpTQpnm71kLBzHn37o8sB..HFtLf.	\N	\N	https://xbdchat.com/avatars/1782914895_JPEG_20251203_160451_4069513748948391968.jpg	2025-11-24 15:13:50.435812	2026-07-03 01:21:17.851289	\N	测试01	male	\N	online	\N	\N				qUXKnX	\N	b1b0820d8627e0499bd6bd5d092c1e71780a27863b886a8166f278343d60417a	2025-12-29 13:50:51.90804	2026-07-03 01:21:13.272318	0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxMDIsInVzZXJuYW1lIjoidGVzdDAxIiwiZXhwIjoxNzgzNjQ2NDczLCJuYmYiOjE3ODMwNDE2NzMsImlhdCI6MTc4MzA0MTY3M30.kLkRlOrtnf-newnbb3umCmbUKlI17PCqsT5gdrxH6wE	2026-07-03 09:21:13.27062+08	\N
106	test05	$2a$10$kn7TCvq3qQTaf8RaURSgauc6k9QRCE6.JWPwmPMw.1JiPa1ZrAcLm	\N	\N	https://xbdchat.com/avatars/1782914861_JPEG_20251129_205735_2533816437738796444.jpg	2025-11-25 09:22:55.250863	2026-07-02 22:57:16.760211	\N	测试05	male	\N	online	\N	\N				4cPntt	\N	\N	\N	2026-07-02 14:56:34.142632	0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxMDYsInVzZXJuYW1lIjoidGVzdDA1IiwiZXhwIjoxNzgzNjA4OTk0LCJuYmYiOjE3ODMwMDQxOTQsImlhdCI6MTc4MzAwNDE5NH0.gpamBydYXJd3ay4FCh7T4kxDQJE8Lf8Z-iFKzE6t0ds	2026-07-02 14:56:34.140573+08	\N
\.


--
-- Data for Name: verification_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verification_codes (id, account, code, type, expires_at, created_at) FROM stdin;
\.


--
-- Name: admin_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admin_user_id_seq', 1, true);


--
-- Name: app_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.app_versions_id_seq', 4, true);


--
-- Name: device_registrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.device_registrations_id_seq', 332, true);


--
-- Name: favorite_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.favorite_contacts_id_seq', 1, false);


--
-- Name: favorite_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.favorite_groups_id_seq', 1, false);


--
-- Name: favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.favorites_id_seq', 1, false);


--
-- Name: file_assistant_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.file_assistant_messages_id_seq', 1, false);


--
-- Name: group_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.group_members_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, false);


--
-- Name: invite_code_usages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invite_code_usages_id_seq', 1, true);


--
-- Name: invite_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invite_codes_id_seq', 10, true);


--
-- Name: scheduled_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.scheduled_messages_id_seq', 1, false);


--
-- Name: server_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.server_settings_id_seq', 5, true);


--
-- Name: synced_group_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.synced_group_messages_id_seq', 1, false);


--
-- Name: synced_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.synced_messages_id_seq', 1, false);


--
-- Name: user_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_relations_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 662, true);


--
-- Name: verification_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.verification_codes_id_seq', 3, true);


--
-- Name: admin_user admin_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_user
    ADD CONSTRAINT admin_user_pkey PRIMARY KEY (id);


--
-- Name: admin_user admin_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_user
    ADD CONSTRAINT admin_user_username_key UNIQUE (username);


--
-- Name: app_versions app_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_versions
    ADD CONSTRAINT app_versions_pkey PRIMARY KEY (id);


--
-- Name: app_versions app_versions_version_platform_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_versions
    ADD CONSTRAINT app_versions_version_platform_key UNIQUE (version, platform);


--
-- Name: device_registrations device_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_registrations
    ADD CONSTRAINT device_registrations_pkey PRIMARY KEY (id);


--
-- Name: device_registrations device_registrations_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_registrations
    ADD CONSTRAINT device_registrations_uuid_key UNIQUE (uuid);


--
-- Name: favorite_contacts favorite_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_contacts
    ADD CONSTRAINT favorite_contacts_pkey PRIMARY KEY (id);


--
-- Name: favorite_contacts favorite_contacts_user_id_contact_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_contacts
    ADD CONSTRAINT favorite_contacts_user_id_contact_id_key UNIQUE (user_id, contact_id);


--
-- Name: favorite_groups favorite_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_groups
    ADD CONSTRAINT favorite_groups_pkey PRIMARY KEY (id);


--
-- Name: favorite_groups favorite_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_groups
    ADD CONSTRAINT favorite_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: favorites favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_pkey PRIMARY KEY (id);


--
-- Name: file_assistant_messages file_assistant_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_assistant_messages
    ADD CONSTRAINT file_assistant_messages_pkey PRIMARY KEY (id);


--
-- Name: group_members group_members_group_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_group_id_user_id_key UNIQUE (group_id, user_id);


--
-- Name: group_members group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: invite_code_usages invite_code_usages_invite_code_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_code_usages
    ADD CONSTRAINT invite_code_usages_invite_code_id_user_id_key UNIQUE (invite_code_id, user_id);


--
-- Name: invite_code_usages invite_code_usages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_code_usages
    ADD CONSTRAINT invite_code_usages_pkey PRIMARY KEY (id);


--
-- Name: invite_codes invite_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_codes
    ADD CONSTRAINT invite_codes_code_key UNIQUE (code);


--
-- Name: invite_codes invite_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_codes
    ADD CONSTRAINT invite_codes_pkey PRIMARY KEY (id);


--
-- Name: scheduled_messages scheduled_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_pkey PRIMARY KEY (id);


--
-- Name: server_settings server_settings_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.server_settings
    ADD CONSTRAINT server_settings_key_key UNIQUE (key);


--
-- Name: server_settings server_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.server_settings
    ADD CONSTRAINT server_settings_pkey PRIMARY KEY (id);


--
-- Name: synced_group_messages synced_group_messages_agora_msg_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.synced_group_messages
    ADD CONSTRAINT synced_group_messages_agora_msg_id_key UNIQUE (agora_msg_id);


--
-- Name: synced_group_messages synced_group_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.synced_group_messages
    ADD CONSTRAINT synced_group_messages_pkey PRIMARY KEY (id);


--
-- Name: synced_messages synced_messages_agora_msg_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.synced_messages
    ADD CONSTRAINT synced_messages_agora_msg_id_key UNIQUE (agora_msg_id);


--
-- Name: synced_messages synced_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.synced_messages
    ADD CONSTRAINT synced_messages_pkey PRIMARY KEY (id);


--
-- Name: user_relations user_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_relations
    ADD CONSTRAINT user_relations_pkey PRIMARY KEY (id);


--
-- Name: user_relations user_relations_user_id_friend_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_relations
    ADD CONSTRAINT user_relations_user_id_friend_id_key UNIQUE (user_id, friend_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: verification_codes verification_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_codes
    ADD CONSTRAINT verification_codes_pkey PRIMARY KEY (id);


--
-- Name: idx_app_versions_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_app_versions_platform ON public.app_versions USING btree (platform);


--
-- Name: idx_app_versions_platform_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_app_versions_platform_status ON public.app_versions USING btree (platform, status);


--
-- Name: idx_app_versions_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_app_versions_status ON public.app_versions USING btree (status);


--
-- Name: idx_device_installed_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_device_installed_at ON public.device_registrations USING btree (installed_at);


--
-- Name: idx_device_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_device_platform ON public.device_registrations USING btree (platform);


--
-- Name: idx_device_uuid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_device_uuid ON public.device_registrations USING btree (uuid);


--
-- Name: idx_favorite_contacts_contact_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorite_contacts_contact_id ON public.favorite_contacts USING btree (contact_id);


--
-- Name: idx_favorite_contacts_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorite_contacts_created_at ON public.favorite_contacts USING btree (created_at DESC);


--
-- Name: idx_favorite_contacts_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorite_contacts_user_id ON public.favorite_contacts USING btree (user_id);


--
-- Name: idx_favorite_groups_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorite_groups_created_at ON public.favorite_groups USING btree (created_at DESC);


--
-- Name: idx_favorite_groups_group_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorite_groups_group_id ON public.favorite_groups USING btree (group_id);


--
-- Name: idx_favorite_groups_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorite_groups_user_id ON public.favorite_groups USING btree (user_id);


--
-- Name: idx_favorites_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorites_created_at ON public.favorites USING btree (created_at DESC);


--
-- Name: idx_favorites_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorites_user_id ON public.favorites USING btree (user_id);


--
-- Name: idx_file_assistant_messages_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_file_assistant_messages_created_at ON public.file_assistant_messages USING btree (created_at DESC);


--
-- Name: idx_file_assistant_messages_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_file_assistant_messages_status ON public.file_assistant_messages USING btree (status);


--
-- Name: idx_file_assistant_messages_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_file_assistant_messages_user_id ON public.file_assistant_messages USING btree (user_id);


--
-- Name: idx_group_members_group_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_group_members_group_id ON public.group_members USING btree (group_id);


--
-- Name: idx_group_members_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_group_members_user_id ON public.group_members USING btree (user_id);


--
-- Name: idx_groups_owner_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_groups_owner_id ON public.groups USING btree (owner_id);


--
-- Name: idx_invite_code_usages_invite_code_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invite_code_usages_invite_code_id ON public.invite_code_usages USING btree (invite_code_id);


--
-- Name: idx_invite_code_usages_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invite_code_usages_user_id ON public.invite_code_usages USING btree (user_id);


--
-- Name: idx_scheduled_messages_receiver_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scheduled_messages_receiver_id ON public.scheduled_messages USING btree (receiver_id);


--
-- Name: idx_scheduled_messages_send_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scheduled_messages_send_date ON public.scheduled_messages USING btree (send_date);


--
-- Name: idx_scheduled_messages_send_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scheduled_messages_send_time ON public.scheduled_messages USING btree (send_time);


--
-- Name: idx_scheduled_messages_sender_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scheduled_messages_sender_id ON public.scheduled_messages USING btree (sender_id);


--
-- Name: idx_scheduled_messages_sender_receiver; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scheduled_messages_sender_receiver ON public.scheduled_messages USING btree (sender_id, receiver_id, message_type);


--
-- Name: idx_scheduled_messages_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scheduled_messages_status ON public.scheduled_messages USING btree (status);


--
-- Name: idx_synced_group_messages_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_synced_group_messages_created_at ON public.synced_group_messages USING btree (created_at DESC);


--
-- Name: idx_synced_group_messages_group; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_synced_group_messages_group ON public.synced_group_messages USING btree (group_id);


--
-- Name: idx_synced_group_messages_sender; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_synced_group_messages_sender ON public.synced_group_messages USING btree (sender_id);


--
-- Name: idx_synced_messages_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_synced_messages_created_at ON public.synced_messages USING btree (created_at DESC);


--
-- Name: idx_synced_messages_receiver; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_synced_messages_receiver ON public.synced_messages USING btree (receiver_id);


--
-- Name: idx_synced_messages_sender; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_synced_messages_sender ON public.synced_messages USING btree (sender_id);


--
-- Name: idx_user_relations_approval_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_relations_approval_status ON public.user_relations USING btree (approval_status);


--
-- Name: idx_user_relations_friend_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_relations_friend_id ON public.user_relations USING btree (friend_id);


--
-- Name: idx_user_relations_is_blocked; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_relations_is_blocked ON public.user_relations USING btree (is_blocked) WHERE (is_blocked = true);


--
-- Name: idx_user_relations_is_deleted; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_relations_is_deleted ON public.user_relations USING btree (is_deleted) WHERE (is_deleted = true);


--
-- Name: idx_user_relations_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_relations_user_id ON public.user_relations USING btree (user_id);


--
-- Name: idx_users_active_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_active_token ON public.users USING btree (active_token);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email) WHERE (email IS NOT NULL);


--
-- Name: idx_users_invite_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_invite_code ON public.users USING btree (invite_code) WHERE (invite_code IS NOT NULL);


--
-- Name: idx_users_invited_by_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_invited_by_code ON public.users USING btree (invited_by_code) WHERE (invited_by_code IS NOT NULL);


--
-- Name: idx_users_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_phone ON public.users USING btree (phone) WHERE (phone IS NOT NULL);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_users_voip_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_voip_token ON public.users USING btree (voip_token) WHERE (voip_token IS NOT NULL);


--
-- Name: idx_verification_codes_account; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_verification_codes_account ON public.verification_codes USING btree (account);


--
-- Name: idx_verification_codes_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_verification_codes_expires_at ON public.verification_codes USING btree (expires_at);


--
-- Name: server_settings update_server_settings_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_server_settings_updated_at BEFORE UPDATE ON public.server_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: favorite_contacts favorite_contacts_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_contacts
    ADD CONSTRAINT favorite_contacts_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: favorite_contacts favorite_contacts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_contacts
    ADD CONSTRAINT favorite_contacts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: favorite_groups favorite_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_groups
    ADD CONSTRAINT favorite_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: favorite_groups favorite_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_groups
    ADD CONSTRAINT favorite_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: favorites favorites_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: favorites favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: file_assistant_messages file_assistant_messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_assistant_messages
    ADD CONSTRAINT file_assistant_messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: group_members group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_members group_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: groups groups_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: invite_code_usages invite_code_usages_invite_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_code_usages
    ADD CONSTRAINT invite_code_usages_invite_code_id_fkey FOREIGN KEY (invite_code_id) REFERENCES public.invite_codes(id) ON DELETE CASCADE;


--
-- Name: invite_code_usages invite_code_usages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_code_usages
    ADD CONSTRAINT invite_code_usages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: invite_codes invite_codes_used_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_codes
    ADD CONSTRAINT invite_codes_used_by_user_id_fkey FOREIGN KEY (used_by_user_id) REFERENCES public.users(id);


--
-- Name: user_relations user_relations_friend_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_relations
    ADD CONSTRAINT user_relations_friend_id_fkey FOREIGN KEY (friend_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_relations user_relations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_relations
    ADD CONSTRAINT user_relations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict oOtTiLJepjFDz7bp80b3kJXtFZZglysrkaijWvxW8UBKxMuDA7fXclJedtXM7BP

